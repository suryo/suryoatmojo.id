<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.general')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.general')); ?></h6>
                </div>
                <div class="card-body">
                    <form class="form-visibility"  action="<?php echo e(url('/').'/admin/general'); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" value="<?php echo e($general->title); ?>" />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label for="description" class="form-label"><?php echo e(__('content.description')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="description" value="<?php echo e($general->description); ?>" />
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group info-content mb-4">
                                        <label for="keywords" class="form-label"><?php echo e(__('content.keywords')); ?></label>
                                        <div class="row">
                                            <div class="col-10">
                                                <div class="input-group mb-3">
                                                    <input type="text" name="keyword_label" id="info_label_keywords-list" class="form-control">
                                                    <input type="hidden" name="keyword_value" id="info_value_keywords-list" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <button type="button" class="btn btn-success w-100 addInfo" data-target="keywords-list"><?php echo e(__('content.add')); ?></button>
                                            </div>
                                            <div class="invalid-feedback d-none invalid-keywords-list">
                                                <?php echo e(__('content.characters_not_valid')); ?>

                                            </div>
                                        </div>
                                        <input type="hidden" name="keywords" value="<?php echo e($general->keywords); ?>" id="keywords-list" />
                                        <div class="table-elements p-4">
                                            <table class="table table-keywords-list w-100 p-4" data-target="keywords-list">
                                                <tbody>
                                                    <?php
                                                    $keywords = json_decode($general->keywords, true);
                                                    if(!empty($keywords)):
                                                        foreach($keywords as $key => $value){
                                                            echo '
                                                            <tr>
                                                                <td class="fw-bold">'.$value["title"].'</td>
                                                                <td>'.$value["text"].'</td>
                                                                <td class="text-right">
                                                                    <button type="button" class="btn btn-outline-danger btn-sm rounded-circle deleteInfo" data-info="'.$value["title"].'" data-value="'.$value["text"].'">
                                                                        <i class="fas fa-times"></i>
                                                                    </button>                                                            
                                                            </tr>';
                                                        }  
                                                    endif; 
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="analytics_code" class="form-label"><?php echo e(__('content.analytics_code')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['analytics_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="analytics_code" value="<?php echo e($general->analytics_code); ?>" />
                                        <div class="form-text d-flex">
                                            <span><?php echo e(__('content.analytics_code_desc')); ?></span>
                                        </div>
                                        <?php $__errorArgs = ['analytics_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group mb-5">
                                        <label for="image_favicon" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image_favicon')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_favicon" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgFaviconUrl = ($general->image_favicon != '') ? $general->image_favicon : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgFaviconUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_favicon" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_favicon" value=""/>
                                        <input type="hidden" name="image_favicon_current" value="<?php echo e($general->image_favicon); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements_png')); ?></span>
                                            <span><?php echo e(__('content.image_size_min')); ?> 155x155px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group mb-5">
                                        <label for="image_logo_header_dark" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image_logo_header_dark')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_logo_header_dark" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgHeaderUrl = ($general->image_logo_header_dark != '') ? $general->image_logo_header_dark : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgHeaderUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_logo_header_dark" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_logo_header_dark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_logo_header_dark" value=""/>
                                        <input type="hidden" name="image_logo_header_dark_current" value="<?php echo e($general->image_logo_header_dark); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 150x60px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_logo_header_dark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group mb-5">
                                        <label for="image_logo_header_light" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image_logo_header_light')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_logo_header_light" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgHeaderUrl = ($general->image_logo_header_light != '') ? $general->image_logo_header_light : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgHeaderUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_logo_header_light" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_logo_header_light'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_logo_header_light" value=""/>
                                        <input type="hidden" name="image_logo_header_light_current" value="<?php echo e($general->image_logo_header_light); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 150x60px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_logoimage_logo_header_light_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group mb-5">
                                        <label for="menu_position" class="form-label w-100"><?php echo e(__('content.menu_position')); ?></label>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="menu_position" value="left" <?php echo e(($general->menu_position == "left") ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e(__('content.left')); ?></label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="menu_position" value="center" <?php echo e(($general->menu_position == "center") ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e(__('content.center')); ?></label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="menu_position" value="right" <?php echo e(($general->menu_position == "right") ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e(__('content.right')); ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group info-content">
                                        <label for="social_links" class="form-label"><?php echo e(__('content.social_links')); ?></label>
                                        <div class="row">
                                            <div class="col-3">
                                                <div class="input-group mb-3">
                                                    <select class="form-select select-social" name="social_network" id="info_label_personal-info">
                                                        <option value="fab fa-facebook-f">Facebok</option>
                                                        <option value="fab fa-twitter">Twitter</option>
                                                        <option value="fab fa-instagram">Instagram</option>
                                                        <option value="fab fa-linkedin-in">Linkedin</option>
                                                        <option value="fab fa-github">GitHub</option>
                                                        <option value="fab fa-pinterest-p">Pinterest</option>
                                                        <option value="fab fa-reddit-alien">Reddit</option>
                                                        <option value="fab fa-snapchat-ghost">Snapchat</option>
                                                        <option value="fab fa-telegram-plane">Telegram</option>
                                                        <option value="fab fa-twitch">Twitch</option>
                                                        <option value="fab fa-vimeo-v">Vimeo</option>
                                                        <option value="fab fa-youtube">Youtube</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-7">
                                                <div class="input-group mb-3">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e(__('content.link')); ?></span>
                                                    </div>
                                                    <input type="text" name="social_links" id="info_value_personal-info" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <button type="button" class="btn btn-success w-100 addInfo" data-target="personal-info"><?php echo e(__('content.add')); ?></button>
                                            </div>
                                            <div class="invalid-feedback d-none invalid-personal-info">
                                                <?php echo e(__('content.characters_not_valid')); ?>

                                            </div>
                                        </div>
                                        <input type="hidden" name="social_links" value="<?php echo e($general->social_links); ?>" id="personal-info" />
                                        <div class="table-elements p-4">
                                            <table class="table table-personal-info w-100" data-target="personal-info">
                                                <tbody>
                                                    <?php
                                                    $social_links = json_decode($general->social_links, true);
                                                    if(!empty($social_links)):
                                                        foreach($social_links as $key => $value){
                                                            echo '
                                                            <tr>
                                                                <td class="fw-bold"><span class="'.$value["title"].'"></span></td>
                                                                <td>'.$value["text"].'</td>
                                                                <td class="text-right">
                                                                    <button type="button" class="btn btn-outline-danger btn-sm rounded-circle deleteInfo" data-info="'.$value["title"].'" data-value="'.$value["text"].'">
                                                                        <i class="fas fa-times"></i>
                                                                    </button>                                                            
                                                            </tr>';
                                                        }  
                                                    endif; 
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold mb-3"><?php echo e(__('content.loader')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="loader" class="form-label"><?php echo e(__('content.loader')); ?></label>
                                        <div class="form-switch mb-3">
                                            <input class="form-check-input" type="checkbox" data-visibility="loader-options" name="loader" <?php echo e(($general->loader == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="loader"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row loader-options <?php echo e(($general->loader == 0) ? 'd-none' : ''); ?>">
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="loader_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                        <select class="form-select <?php $__errorArgs = ['loader_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="loader_scheme_color">
                                            <option value="light-scheme" <?php echo ($general->loader_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                            <option value="dark-scheme" <?php echo ($general->loader_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="image_logo_loader" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image_logo_loader')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_logo_loader" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgLoaderUrl = ($general->image_logo_loader != '') ? $general->image_logo_loader : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgLoaderUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_logo_loader" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_logo_loader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_logo_loader" value=""/>
                                        <input type="hidden" name="image_logo_loader_current" value="<?php echo e($general->image_logo_loader); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 160x160px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_logo_loader'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold mb-3"><?php echo e(__('content.cookies')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="cookies_enable" class="form-label"><?php echo e(__('content.cookies')); ?></label>
                                        <div class="form-switch mb-3">
                                            <input class="form-check-input" type="checkbox" data-visibility="cookies-options" name="cookies_enable" <?php echo e(($general->cookies_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cookies_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row cookies-options <?php echo e(($general->cookies_enable == 0) ? 'd-none' : ''); ?>">
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="cookies_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                        <select class="form-select <?php $__errorArgs = ['loader_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cookies_color">
                                            <option value="light-scheme" <?php echo ($general->cookies_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                            <option value="dark-scheme" <?php echo ($general->cookies_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="cookies_style" class="form-label"><?php echo e(__('content.style')); ?></label>
                                        <select class="form-select <?php $__errorArgs = ['cookies_style'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cookies_style">
                                            <option value="boxed-left" <?php echo ($general->cookies_style == 'boxed-left') ? 'selected' : ''; ?>><?php echo e(__('content.boxed_left')); ?></option>
                                            <option value="boxed-right" <?php echo ($general->cookies_style == 'boxed-right') ? 'selected' : ''; ?>><?php echo e(__('content.boxed_right')); ?></option>
                                            <option value="wide" <?php echo ($general->cookies_style == 'wide') ? 'selected' : ''; ?>><?php echo e(__('content.wide')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="cookies_alignment" class="form-label"><?php echo e(__('content.text_alignment')); ?></label>
                                        <select class="form-select <?php $__errorArgs = ['cookies_alignment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cookies_alignment">
                                            <option value="start" <?php echo ($general->cookies_alignment == 'start') ? 'selected' : ''; ?>><?php echo e(__('content.left')); ?></option>
                                            <option value="center" <?php echo ($general->cookies_alignment == 'center') ? 'selected' : ''; ?>><?php echo e(__('content.center')); ?></option>
                                            <option value="end" <?php echo ($general->cookies_alignment == 'end') ? 'selected' : ''; ?>><?php echo e(__('content.right')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['cookies_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="cookies_title" value="<?php echo e($general->cookies_title); ?>" />
                                        <?php $__errorArgs = ['cookies_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="cookies_text" class="form-label"><?php echo e(__('content.text')); ?></label>
                                    <textarea class="form-control summernote-simple <?php $__errorArgs = ['cookies_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cookies_text"><?php echo e($general->cookies_text); ?></textarea>
                                    <?php $__errorArgs = ['cookies_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-none">
                                            <?php echo e(__('content.text_not_valid')); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary check-summernote">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/general.blade.php ENDPATH**/ ?>