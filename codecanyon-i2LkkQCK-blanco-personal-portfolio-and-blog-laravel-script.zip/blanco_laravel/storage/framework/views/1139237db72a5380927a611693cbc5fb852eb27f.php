<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.personal_info')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.personal_info')); ?></h6>
                </div>
                <div class="card-body">
                    <form class="form-visibility" action="<?php echo e(url('/').'/admin/personal'); ?>" method="POST" enctype="multipart/form-data" class="personal-info-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="image" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_profile" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgPersonalUrl = ($personal->image != '') ? $personal->image : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-4 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgPersonalUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_profile" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_profile" value=""/>
                                        <input type="hidden" name="image_profile_current" value="<?php echo e($personal->image); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 700x1100px</span>
                                        </div>
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-none">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" value="<?php echo e($personal->title); ?>" required />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div class="form-text">
                                            <span><?php echo e(__('content.line_mark')); ?></span>
                                        </div>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label for="description" class="form-label"><?php echo e(__('content.description')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" cols="30" rows="10"><?php echo e($personal->description); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group mb-4">
                                        <label for="cv_enable" class="form-label"><?php echo e(__('content.cv_enable')); ?></label>
                                        <div class="form-switch mb-4">
                                            <input class="form-check-input" type="checkbox" id="cv_enable" data-visibility="cv-options" name="cv_enable" <?php echo e(($personal->cv_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cv_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                    <div class="row cv-options <?php echo e(($personal->cv_enable == 0) ? 'd-none' : ''); ?>">
                                        <div class="form-group mb-4 cv-text-field">
                                            <label for="cv_text" class="form-label"><?php echo e(__('content.cv_text')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['cv_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="cv_text" value="<?php echo e($personal->cv_text); ?>" />
                                            <?php $__errorArgs = ['cv_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-none">
                                                    <?php echo e(__('content.text_not_valid')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-4 cv-file-field">
                                            <label for="cvfile" class="form-label w-100"><?php echo e(__('content.cv_file')); ?>

                                            <?php if($personal->cv_file != ''): ?>
                                                <span class="float-end fst-italic fw-normal text-success"><?php echo e(__('content.current_file')); ?> <?php echo e(Str::substr($personal->cv_file, 23)); ?></span>
                                            <?php endif; ?>
                                            </label>
                                            <input class="form-control" type="file" name="cvfile" value="" />
                                            <div class="form-text"><?php echo e(__('content.file_requirements')); ?></div>
                                            <input type="hidden" name="cv_file_current" value="<?php echo e($personal->cv_file); ?>" />
                                        </div>
                                    </div>
                                    <hr class="mt-4 mb-5 border-top-0">
                                    <div class="form-group info-content mb-4">
                                        <label for="info" class="form-label"><?php echo e(__('content.info')); ?></label>
                                        <div class="row">
                                            <div class="col-5">
                                                <div class="input-group mb-4">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e(__('content.info_min')); ?></span>
                                                    </div>
                                                    <input type="text" name="info_label" id="info_label_personal-info" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="input-group mb-4">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e(__('content.text')); ?></span>
                                                    </div>
                                                    <input type="text" name="info_value" id="info_value_personal-info" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <button type="button" class="btn btn-success w-100 addInfo" data-target="personal-info"><?php echo e(__('content.add')); ?></button>
                                            </div>
                                            <div class="invalid-feedback d-none invalid-personal-info">
                                                <?php echo e(__('content.characters_not_valid')); ?>

                                            </div>
                                        </div>
                                        <input type="hidden" name="personal_info" value="<?php echo e($personal->info); ?>" id="personal-info" />
                                        <div class="table-elements p-4">
                                            <table class="table table-personal-info w-100" data-target="personal-info">
                                                <tbody>
                                                    <?php
                                                    $info = json_decode($personal->info, true);
                                                    if(!empty($info)):
                                                        foreach($info as $key => $value){
                                                            echo '
                                                            <tr>
                                                                <td class="fw-bold">'.$value["title"].'</td>
                                                                <td>'.$value["text"].'</td>
                                                                <td class="text-right">
                                                                    <button type="button" class="btn btn-outline-danger rounded-circle deleteInfo" data-info="'.$value["title"].'" data-value="'.$value["text"].'">
                                                                        <i class="fas fa-times"></i>
                                                                    </button>                                                            
                                                            </tr>';
                                                        }  
                                                    endif; 
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/personal.blade.php ENDPATH**/ ?>