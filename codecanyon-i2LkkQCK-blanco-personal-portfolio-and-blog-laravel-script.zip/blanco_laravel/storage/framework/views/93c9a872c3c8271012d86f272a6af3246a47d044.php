<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.sections')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.sections')); ?></h6>
                </div>
                <div class="card-body">
                    <form class="form-visibility" action="<?php echo e(url('/').'/admin/sections'); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">

                                
                                <div class="col-12 mb-2">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.slider_section')); ?></h4>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="slider_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="slider_enable" <?php echo e(($section->slider_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="slider_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="form-group">
                                        <label for="slider_id" class="form-label"><?php echo e(__('content.slider')); ?></label>
                                        <select class="form-select <?php $__errorArgs = ['slider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="slider_id">
                                        <?php echo e($i=1); ?>

                                            <option value="null" <?php echo e(($section->slider_id == null) ? 'selected' : ''); ?>><?php echo e(__('content.none')); ?></option>
                                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($slider->id); ?>" <?php echo e(($section->slider_id == $slider->id) ? 'selected' : ''); ?>><?php echo e($i); ?>: <?php echo e(ucfirst($slider->type)); ?> <?php if($slider->type == 'video'): ?> <?php echo e($slider->video_type); ?> <?php endif; ?></option>
                                            <?php echo e($i++); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.about_me_section')); ?></h4>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <div class="form-group">
                                        <label for="about_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" data-visibility="about-me-options" name="about_enable" <?php echo e(($section->about_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="about_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row about-me-options <?php echo e(($section->about_enable == 0) ? 'd-none' : ''); ?>">
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="about_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['about_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="about_scheme_color">
                                                <option value="light-scheme" <?php echo ($section->about_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                <option value="dark-scheme" <?php echo ($section->about_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="about_menu" class="form-label"><?php echo e(__('content.menu')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['about_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="about_menu" value="<?php echo e($section->about_menu); ?>" />
                                            <?php $__errorArgs = ['about_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    
                                    <div class="col-12 mb-2">
                                        <h5 class="mt-4 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.skills_section')); ?></h5>
                                    </div>
                                    <div class="col-md-12 mb-2">
                                        <div class="form-group">
                                            <label for="skills_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                            <div class="form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" data-visibility="skills-options" name="skills_enable" <?php echo e(($section->skills_enable == 1) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="skills_enable"><?php echo e(__('content.enable')); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row skills-options <?php echo e(($section->skills_enable == 0) ? 'd-none' : ''); ?>">
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group mb-3">
                                                <label for="skills_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                                <select class="form-select <?php $__errorArgs = ['skills_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="skills_scheme_color">
                                                    <option value="light-scheme" <?php echo ($section->skills_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                    <option value="dark-scheme" <?php echo ($section->skills_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                                </select>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="skills_title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                                <input class="form-control <?php $__errorArgs = ['skills_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="skills_title" value="<?php echo e($section->skills_title); ?>" />
                                                <?php $__errorArgs = ['skills_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="skills_subtitle" class="form-label"><?php echo e(__('content.subtitle')); ?></label>
                                                <input class="form-control <?php $__errorArgs = ['skills_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="skills_subtitle" value="<?php echo e($section->skills_subtitle); ?>" />
                                                <?php $__errorArgs = ['skills_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group">
                                                <label for="skills_background" class="form-label d-flex justify-content-between">
                                                    <?php echo e(__('content.background')); ?>

                                                    <span class="fw-normal fst-italic remove-image text-primary" data-target="skills_background" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                                </label>
                                                <?php
                                                    $imgSkillsUrl = ($section->skills_background != '') ? $section->skills_background : 'uploads/img/image_default.png';
                                                ?>
                                                <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                    <img src="<?php echo e(asset('/')); ?>/<?php echo $imgSkillsUrl; ?>" class="img-fluid img-maxsize-200 previewImage_skills_background" />
                                                </div>
                                                <input class="form-control previewImage <?php $__errorArgs = ['skills_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="skills_background" value=""/>
                                                <input type="hidden" name="skills_background_current" value="<?php echo e($section->skills_background); ?>" />
                                                <div class="form-text d-flex justify-content-between">
                                                    <span><?php echo e(__('content.image_requirements')); ?></span>
                                                    <span><?php echo e(__('content.image_size_recommended')); ?> 1280x600px</span>
                                                </div>
                                                <?php $__errorArgs = ['skills_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.error_validation_image')); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div> 

                                    
                                    <div class="col-12 mb-2">
                                        <h5 class="mt-4 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.testimonials_section')); ?></h5>
                                    </div>
                                    <div class="col-md-12 mb-2">
                                        <div class="form-group">
                                            <label for="testimonial_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                            <div class="form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" data-visibility="testimonials-options" name="testimonial_enable" <?php echo e(($section->testimonial_enable == 1) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="testimonial_enable"><?php echo e(__('content.enable')); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row testimonials-options <?php echo e(($section->testimonial_enable == 0) ? 'd-none' : ''); ?>">
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group mb-4">
                                                <label for="testimonial_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                                <select class="form-select <?php $__errorArgs = ['testimonial_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="testimonial_scheme_color">
                                                    <option value="light-scheme" <?php echo ($section->testimonial_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                    <option value="dark-scheme" <?php echo ($section->testimonial_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="testimonial_interval" class="form-label"><?php echo e(__('content.interval_time')); ?></label>
                                                <input class="form-control <?php $__errorArgs = ['testimonial_interval'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" min="0" name="testimonial_interval" value="<?php echo e($section->testimonial_interval); ?>" />
                                                <?php $__errorArgs = ['testimonial_interval'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.number_not_valid')); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="testimonial_autoplay" class="form-label"><?php echo e(__('content.autoplay')); ?></label>
                                                <div class="form-switch mb-2">
                                                    <input class="form-check-input" type="checkbox" name="testimonial_autoplay" <?php echo e(($section->testimonial_autoplay == 1) ? 'checked' : ''); ?>>
                                                    <label class="form-check-label" for="testimonial_autoplay"><?php echo e(__('content.enable')); ?></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group">
                                                <label for="testimonial_background" class="form-label d-flex justify-content-between">
                                                    <?php echo e(__('content.background')); ?>

                                                    <span class="fw-normal fst-italic remove-image text-primary" data-target="testimonial_background" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                                </label>
                                                <?php
                                                    $imgTestimonialUrl = ($section->testimonial_background != '') ? $section->testimonial_background : 'uploads/img/image_default.png';
                                                ?>
                                                <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                    <img src="<?php echo e(asset('/')); ?>/<?php echo $imgTestimonialUrl; ?>" class="img-fluid img-maxsize-200 previewImage_testimonial_background" />
                                                </div>
                                                <input class="form-control previewImage <?php $__errorArgs = ['testimonial_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="testimonial_background" value=""/>
                                                <input type="hidden" name="testimonial_background_current" value="<?php echo e($section->testimonial_background); ?>" />
                                                <div class="form-text d-flex justify-content-between">
                                                    <span><?php echo e(__('content.image_requirements')); ?></span>
                                                    <span><?php echo e(__('content.image_size_recommended')); ?> 1280x600px</span>
                                                </div>
                                                <?php $__errorArgs = ['testimonial_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.error_validation_image')); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div> 
                                    
                                    
                                    <div class="col-12 mb-2">
                                        <h5 class="mt-4 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.services_section')); ?></h5>
                                    </div>
                                    <div class="col-md-12 mb-2">
                                        <div class="form-group">
                                            <label for="services_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                            <div class="form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" data-visibility="services-options" name="services_enable" <?php echo e(($section->services_enable == 1) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="services_enable"><?php echo e(__('content.enable')); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row services-options <?php echo e(($section->services_enable == 0) ? 'd-none' : ''); ?>">
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group mb-3">
                                                <label for="services_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                                <select class="form-select <?php $__errorArgs = ['services_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="services_scheme_color">
                                                    <option value="light-scheme" <?php echo ($section->services_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                    <option value="dark-scheme" <?php echo ($section->services_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                                </select>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="services_title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                                <input class="form-control <?php $__errorArgs = ['services_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="services_title" value="<?php echo e($section->services_title); ?>" />
                                                <?php $__errorArgs = ['services_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="services_subtitle" class="form-label"><?php echo e(__('content.subtitle')); ?></label>
                                                <input class="form-control <?php $__errorArgs = ['services_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="services_subtitle" value="<?php echo e($section->services_subtitle); ?>" />
                                                <?php $__errorArgs = ['services_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="services_columns" class="form-label"><?php echo e(__('content.columns')); ?></label>
                                                <select class="form-select <?php $__errorArgs = ['services_columns'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="services_columns">
                                                    <option value="2" <?php echo ($section->services_columns == 2) ? 'selected' : ''; ?>>2</option>
                                                    <option value="3" <?php echo ($section->services_columns == 3) ? 'selected' : ''; ?>>3</option>
                                                    <option value="4" <?php echo ($section->services_columns == 4) ? 'selected' : ''; ?>>4</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <div class="form-group">
                                                <label for="services_background" class="form-label d-flex justify-content-between">
                                                    <?php echo e(__('content.background')); ?>

                                                    <span class="fw-normal fst-italic remove-image text-primary" data-target="services_background" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                                </label>
                                                <?php
                                                    $imgServicesUrl = ($section->services_background != '') ? $section->services_background : 'uploads/img/image_default.png';
                                                ?>
                                                <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                    <img src="<?php echo e(asset('/')); ?>/<?php echo $imgServicesUrl; ?>" class="img-fluid img-maxsize-200 previewImage_services_background" />
                                                </div>
                                                <input class="form-control previewImage <?php $__errorArgs = ['services_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="services_background" value=""/>
                                                <input type="hidden" name="services_background_current" value="<?php echo e($section->services_background); ?>" />
                                                <div class="form-text d-flex justify-content-between">
                                                    <span><?php echo e(__('content.image_requirements')); ?></span>
                                                    <span><?php echo e(__('content.image_size_recommended')); ?> 1280x600px</span>
                                                </div>
                                                <?php $__errorArgs = ['services_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e(__('content.error_validation_image')); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div> 

                                </div> 

                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.projects_section')); ?></h4>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <div class="form-group">
                                        <label for="projects_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" data-visibility="projects-options" name="projects_enable" <?php echo e(($section->projects_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="projects_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row projects-options <?php echo e(($section->projects_enable == 0) ? 'd-none' : ''); ?>">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="projects_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['projects_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="projects_scheme_color">
                                                <option value="light-scheme" <?php echo ($section->projects_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                <option value="dark-scheme" <?php echo ($section->projects_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                            </select>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="projects_menu" class="form-label"><?php echo e(__('content.menu')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['projects_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="projects_menu" value="<?php echo e($section->projects_menu); ?>"/>
                                            <?php $__errorArgs = ['projects_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="projects_title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['projects_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="projects_title" value="<?php echo e($section->projects_title); ?>" />
                                            <?php $__errorArgs = ['projects_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="projects_subtitle" class="form-label"><?php echo e(__('content.subtitle')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['projects_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="projects_subtitle" value="<?php echo e($section->projects_subtitle); ?>" />
                                            <?php $__errorArgs = ['projects_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="projects_style" class="form-label"><?php echo e(__('content.style')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['projects_style'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="projects_style">
                                                <option value="1" <?php echo ($section->projects_style == '1') ? 'selected' : ''; ?>><?php echo e(__('content.style')); ?> 1</option>
                                                <option value="2" <?php echo ($section->projects_style == '2') ? 'selected' : ''; ?>><?php echo e(__('content.style')); ?> 2</option>
                                                <option value="3" <?php echo ($section->projects_style == '3') ? 'selected' : ''; ?>><?php echo e(__('content.style')); ?> 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="projects_background" class="form-label d-flex justify-content-between">
                                                <?php echo e(__('content.background')); ?>

                                                <span class="fw-normal fst-italic remove-image text-primary" data-target="projects_background" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                            </label>
                                            <?php
                                                $imgProjectsUrl = ($section->projects_background != '') ? $section->projects_background : 'uploads/img/image_default.png';
                                            ?>
                                            <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                <img src="<?php echo e(asset('/')); ?>/<?php echo $imgProjectsUrl; ?>" class="img-fluid img-maxsize-200 previewImage_projects_background" />
                                            </div>
                                            <input class="form-control previewImage <?php $__errorArgs = ['projects_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="projects_background" value=""/>
                                            <input type="hidden" name="projects_background_current" value="<?php echo e($section->projects_background); ?>" />
                                            <div class="form-text d-flex justify-content-between">
                                                <span><?php echo e(__('content.image_requirements')); ?></span>
                                                <span><?php echo e(__('content.image_size_recommended')); ?> 1280x600px</span>
                                            </div>
                                            <?php $__errorArgs = ['projects_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.error_validation_image')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div> 

                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.blog_section')); ?></h4>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <div class="form-group">
                                        <label for="blog_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" data-visibility="blog-options" name="blog_enable" <?php echo e(($section->blog_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="blog_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row blog-options <?php echo e(($section->blog_enable == 0) ? 'd-none' : ''); ?>">
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group mb-3">
                                            <label for="blog_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['blog_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="blog_scheme_color">
                                                <option value="light-scheme" <?php echo ($section->blog_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                <option value="dark-scheme" <?php echo ($section->blog_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                            </select>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="blog_menu" class="form-label"><?php echo e(__('content.menu')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['blog_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="blog_menu" value="<?php echo e($section->blog_menu); ?>" />
                                            <?php $__errorArgs = ['blog_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="blog_title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['blog_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="blog_title" value="<?php echo e($section->blog_title); ?>" />
                                            <?php $__errorArgs = ['blog_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="blog_subtitle" class="form-label"><?php echo e(__('content.subtitle')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['blog_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="blog_subtitle" value="<?php echo e($section->blog_subtitle); ?>" />
                                            <?php $__errorArgs = ['blog_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="blog_columns" class="form-label"><?php echo e(__('content.columns')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['blog_columns'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="blog_columns">
                                                <option value="2" <?php echo ($section->blog_columns == 2) ? 'selected' : ''; ?>>2</option>
                                                <option value="3" <?php echo ($section->blog_columns == 3) ? 'selected' : ''; ?>>3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="blog_background" class="form-label d-flex justify-content-between">
                                                <?php echo e(__('content.background')); ?>

                                                <span class="fw-normal fst-italic remove-image text-primary" data-target="blog_background" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                            </label>
                                            <?php
                                                $imgBlogUrl = ($section->blog_background != '') ? $section->blog_background : 'uploads/img/image_default.png';
                                            ?>
                                            <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                <img src="<?php echo e(asset('/')); ?>/<?php echo $imgBlogUrl; ?>" class="img-fluid img-maxsize-200 previewImage_blog_background" />
                                            </div>
                                            <input class="form-control previewImage <?php $__errorArgs = ['blog_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="blog_background" value=""/>
                                            <input type="hidden" name="blog_background_current" value="<?php echo e($section->blog_background); ?>" />
                                            <div class="form-text d-flex justify-content-between">
                                                <span><?php echo e(__('content.image_requirements')); ?></span>
                                                <span><?php echo e(__('content.image_size_recommended')); ?> 1280x600px</span>
                                            </div>
                                            <?php $__errorArgs = ['blog_background'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.error_validation_image')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div> 

                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.contact_section')); ?></h4>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <div class="form-group">
                                        <label for="contact_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" data-visibility="contact-options" name="contact_enable" <?php echo e(($section->contact_enable == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="contact_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row contact-options <?php echo e(($section->contact_enable == 0) ? 'd-none' : ''); ?>">
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="contact_scheme_color" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                            <select class="form-select <?php $__errorArgs = ['contact_scheme_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact_scheme_color">
                                                <option value="light-scheme" <?php echo ($section->contact_scheme_color == 'light-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.light_scheme')); ?></option>
                                                <option value="dark-scheme" <?php echo ($section->contact_scheme_color == 'dark-scheme') ? 'selected' : ''; ?>><?php echo e(__('content.dark_scheme')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="contact_menu" class="form-label"><?php echo e(__('content.menu')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['contact_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="contact_menu" value="<?php echo e($section->contact_menu); ?>" />
                                            <?php $__errorArgs = ['contact_menu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="contact_title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['contact_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="contact_title" value="<?php echo e($section->contact_title); ?>" />
                                            <?php $__errorArgs = ['contact_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="contact_subtitle" class="form-label"><?php echo e(__('content.subtitle')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['contact_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="contact_subtitle" value="<?php echo e($section->contact_subtitle); ?>" />
                                            <?php $__errorArgs = ['contact_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="contact_text" class="form-label"><?php echo e(__('content.text')); ?></label>
                                            <textarea class="form-control <?php $__errorArgs = ['contact_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact_text" rows="5"><?php echo e($section->contact_text); ?></textarea>
                                            <?php $__errorArgs = ['contact_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 mb-2">
                                        <h5 class="mt-4 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.map_section')); ?></h5>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="map_enable" class="form-label"><?php echo e(__('content.enable_section')); ?></label>
                                            <div class="form-switch mb-2">
                                                <input class="form-check-input" type="checkbox" name="map_enable" <?php echo e(($section->map_enable == 1) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="map_enable"><?php echo e(__('content.enable')); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/sections.blade.php ENDPATH**/ ?>