<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link text-gray-600" href="<?php echo e(url('/')); ?>" role="button" target="_blank">
                <i class="fas fa-share mr-2"></i>
                <span class="d-lg-inline small"><?php echo e(__('menu.visit_website')); ?></span>
            </a>
        </li>

        <div class="topbar-divider d-none d-sm-block"></div>

        <li class="nav-item dropdown nav-item-user no-arrow">
            <a class="nav-link dropdown-toggle text-gray-600" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" 
            aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline small"><?php echo e($user->name); ?></span>
                <?php
                if ($user->image != null) {
                    echo '<img src="'.asset('/').$user->image.'" alt="'.$user->name.'" class="img-fluid rounded-circle bg-gray-200 p-1" />';
                } else {
                    echo '<i class="fas fa-user-circle h4 m-0"></i>';
                }
                ?>
            </a>
            
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in px-5 py-4" aria-labelledby="userDropdown">
                
                <div class="d-flex align-items-center user-info">
                    <div class="flex-shrink-0">
                        <?php
                        if ($user->image != null) {
                            echo '<img src="'.asset('/').$user->image.'" alt="'.$user->name.'" class="img-fluid rounded-circle bg-gray-200 p-1" />';
                        } else {
                            echo '<i class="fas fa-user-circle h4 m-0"></i>';
                        }
                        ?>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <a href="<?php echo e(url('admin/profile')); ?>" title="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></a>
                        <p class="m-0"><?php echo e($user->email); ?></p>
                    </div>
                </div>
                
                <hr class="dropdown-divider my-3">
                
                <a class="dropdown-item text-gray-600" href="<?php echo e(url('admin/profile')); ?>">
                    <i class="fas fa-list fa-sm fa-fw mr-2"></i>
                    <?php echo e(__('menu.user_profile')); ?>

                </a>
                <a class="dropdown-item text-gray-600" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();document.getElementById('logout.form').submit()">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2"></i>
                    <?php echo e(__('menu.logout')); ?>

                </a>
                <form id="logout.form" action="<?php echo e(route('logout')); ?>" method="post" style="display: none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>

        </li>

    </ul>

</nav>
<?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/modules/header.blade.php ENDPATH**/ ?>