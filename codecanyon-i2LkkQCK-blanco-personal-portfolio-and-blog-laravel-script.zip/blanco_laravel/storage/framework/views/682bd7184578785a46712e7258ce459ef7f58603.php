<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.new_project')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.new_project')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/')); ?>/admin/work/project" method="POST" class="user" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <input type="hidden" name="order" value="<?php echo (count($projects) > 0) ? (count($projects)+1) : 1; ?>" />
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label for="enable_project" class="form-label"><?php echo e(__('content.enable')); ?></label>
                                    <div class="form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" name="enable_project" checked />
                                        <label class="form-check-label" for="enable_project"><?php echo e(__('content.enable')); ?></label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" value="<?php echo e(old('title')); ?>" required />
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-4">
                                        <label for="short_desc" class="form-label"><?php echo e(__('content.short_desc')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['short_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="short_desc" value="<?php echo e(old('short_desc')); ?>" required />
                                        <?php $__errorArgs = ['short_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-4">
                                        <div class="form-group">
                                            <label for="image" class="form-label"><?php echo e(__('content.image')); ?></label>
                                            <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                <img src="<?php echo e(asset('/')); ?>/uploads/img/image_default.png" class="img-fluid img-maxsize-200 previewImage_image" />
                                            </div>
                                            <input class="form-control previewImage <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image" value=""/>
                                            <div class="form-text d-flex justify-content-between">
                                                <span><?php echo e(__('content.image_requirements')); ?></span>
                                                <span><?php echo e(__('content.image_size_recommended')); ?> 900x550px</span>
                                            </div>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.error_validation_image')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="category" class="form-label"><?php echo e(__('content.category')); ?></label>
                                        <select class="form-select" name="category">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="info-content mb-3">
                                        <label for="info" class="form-label"><?php echo e(__('content.info')); ?></label>
                                        <div class="row">
                                            <div class="col-5">
                                                <div class="input-group mb-4">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e(__('content.info_min')); ?></span>
                                                    </div>
                                                    <input type="text" name="info_label" id="info_label_personal-info" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-5">
                                                <div class="input-group mb-4">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e(__('content.text')); ?></span>
                                                    </div>
                                                    <input type="text" name="info_value" id="info_value_personal-info" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <button type="button" class="btn btn-success w-100 addInfo" data-target="personal-info"><?php echo e(__('content.add')); ?></button>
                                            </div>
                                            <div class="invalid-feedback d-none invalid-personal-info">
                                                <?php echo e(__('content.characters_not_valid')); ?>

                                            </div>
                                        </div>
                                        <input type="hidden" name="info" value="" data-target="personal-info" id="personal-info" />
                                        <div class="table-elements p-4">
                                            <table class="table table-personal-info w-100" data-target="personal-info">
                                                <tbody>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="description" class="form-label"><?php echo e(__('content.description')); ?></label>
                                    <?php
                                        $images_value = mt_rand(10,9999);    
                                    ?>
                                    <input type="hidden" name="images_code" value="project_<?php echo $images_value ?>" />
                                    <textarea class="form-control summernote <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" data-folder="uploads/img/temp" data-route="<?php echo e(url('/')); ?>" data-code="project_<?php echo $images_value; ?>"><?php echo e(old('description')); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-none">
                                            <?php echo e(__('content.text_not_valid')); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 mb-3">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.media')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="type" class="form-label"><?php echo e(__('content.type')); ?></label>
                                    <select class="form-select form-select-visibility <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type">
                                        <option value="standard"><?php echo e(__('content.standard')); ?></option>
                                        <option value="gallery"><?php echo e(__('content.gallery')); ?></option>
                                        <option value="video" data-visibility="video-options"><?php echo e(__('content.video')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e(__('content.select_not_valid')); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="image_more_1" class="form-label d-flex justify-content-between">
                                                <?php echo e(__('content.image')); ?> 1
                                                <span class="fw-normal fst-italic remove-image text-primary" data-target="image_more_1" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                            </label>
                                            <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                <img src="<?php echo e(asset('/')); ?>/uploads/img/image_default.png" class="img-fluid img-maxsize-200 previewImage_image_more_1" />
                                            </div>
                                            <input class="form-control previewImage <?php $__errorArgs = ['image_more_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_more_1" value=""/>
                                            <div class="form-text d-flex justify-content-between">
                                                <span><?php echo e(__('content.image_requirements')); ?></span>
                                                <span><?php echo e(__('content.image_size_recommended')); ?> 900x550px</span>
                                            </div>
                                            <?php $__errorArgs = ['image_more_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.error_validation_image')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="image_more_2" class="form-label d-flex justify-content-between">
                                                <?php echo e(__('content.image')); ?> 2
                                                <span class="fw-normal fst-italic remove-image text-primary" data-target="image_more_2" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                            </label>
                                            <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                                <img src="<?php echo e(asset('/')); ?>/uploads/img/image_default.png" class="img-fluid img-maxsize-200 previewImage_image_more_2" />
                                            </div>
                                            <input class="form-control previewImage <?php $__errorArgs = ['image_more_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_more_2" value=""/>
                                            <div class="form-text d-flex justify-content-between">
                                                <span><?php echo e(__('content.image_requirements')); ?></span>
                                                <span><?php echo e(__('content.image_size_recommended')); ?> 900x550px</span>
                                            </div>
                                            <?php $__errorArgs = ['image_more_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.error_validation_image')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row row-visibility video-options d-none">
                                    <div class="col-md-6 mb-2">
                                        <div class="form-group">
                                            <label for="video" class="form-label"><?php echo e(__('content.video')); ?></label>
                                            <input class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="video" <?php echo e(old('video')); ?> />
                                            <div class="form-text"><?php echo e(__('content.video_iframe_requirements')); ?><br/> Example: &#60;iframe ... src="<strong>https://www.youtube.com/embed/kn-1D5z3-Cs</strong> ...&#62;&#60;/iframe&#62;</div>
                                            <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e(__('content.iframe_not_valid')); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary check-summernote">
                                <?php echo e(__('content.add')); ?>

                            </button>
                            <a href="<?php echo e(url('/')); ?>/admin/work/projects">
                                <button type="button" class="btn btn-secondary"><?php echo e(__('content.cancel')); ?></button>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/work/project.blade.php ENDPATH**/ ?>