<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.blog')); ?></h1>
    </div>

    <div class="row">
        
        
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.blog')); ?></h6>
                    <a href="<?php echo e(url('/')); ?>/admin/blog/post" class="btn btn-primary btn-round d-inline">
                        <i class="fas fa-plus small"></i>
                        <?php echo e(__('content.add_post')); ?>

                    </a>
                </div>
                <div class="card-body">
                    <?php if(count($blog) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.title')); ?></th>
                                        <th><?php echo e(__('content.date')); ?></th>
                                        <th><?php echo e(__('content.category')); ?></th>
                                        <th><?php echo e(__('content.type')); ?></th>
                                        <th class="max-w-150"><?php echo e(__('content.media')); ?></th>
                                        <th><?php echo e(__('content.status')); ?></th>
                                        <th><?php echo e(__('content.order')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($post->title); ?></td>
                                            <td><?php echo e(Str::replace('-', '/', $post->created_at)); ?></td>
                                            <td>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if( $post->category_id == $category->id): ?>
                                                    <?php echo e($category->name); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php switch($post->type):
                                                    case ('standard'): ?>
                                                        <i class="far fa-image h4 text-black-25" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.standard')); ?>"></i>
                                                        <?php break; ?>
                                                    <?php case ('gallery'): ?>
                                                        <i class="far fa-images h4 text-black-25" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.gallery')); ?>"></i>
                                                        <?php break; ?>
                                                    <?php case ('video'): ?>
                                                        <i class="fas fa-video h4 text-black-25" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.video')); ?>"></i>
                                                        <?php break; ?>
                                                    <?php case ('quote'): ?>
                                                        <i class="fas fa-quote-right h4 text-black-25" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.quote')); ?>"></i>
                                                        <?php break; ?>
                                                <?php endswitch; ?>
                                            <td>
                                                <?php if($post->type == 'gallery'): ?>
                                                    <form class="d-inline-block w-100" action="<?php echo e(url('/admin/blog/gallery')); ?>" method="POST" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-success btn-icon-split btn-sm mb-1 justify-content-start w-100 min-w-150" data-bs-toggle="modal" data-bs-target="#addImage<?php echo e($post->id); ?>">
                                                            <span class="icon text-white-50">
                                                                <i class="fas fa-plus"></i>
                                                            </span>
                                                            <span class="text"><?php echo e(__('content.add_image')); ?></span>
                                                        </button>
                                                        <div class="modal fade" id="addImage<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('content.add_image')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="col-md-12">
                                                                            <div class="form-group">
                                                                                <label class="form-label"><?php echo e(__('content.slider_image')); ?></label>
                                                                                <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                                                                    <img src="<?php echo e(asset('/')); ?>uploads/img/image_default.png" class="img-fluid img-maxsize-200 previewImage_gallery_image" />
                                                                                </div>
                                                                                <input class="form-control previewImage" type="file" name="gallery_image" required/>
                                                                                <div class="form-text"><?php echo e(__('content.image_requirements')); ?></div>
                                                                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>"/>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-primary">
                                                                            <?php echo e(__('content.add')); ?>

                                                                        </button>
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('content.close')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($image['blog_id'] == $post->id): ?>
                                                            <a href="<?php echo e(url('/')); ?>/admin/blog/gallery/<?php echo e($post->id); ?>" class="btn btn-info btn-icon-split btn-sm justify-content-start w-100">
                                                                <span class="icon text-white-50">
                                                                    <i class="far fa-file-image"></i>
                                                                </span>
                                                                <span class="text"><?php echo e(__('content.images')); ?></span>
                                                            </a>
                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php elseif($post->type == 'video'): ?>
                                                    <?php
                                                    $arrayVideo = explode(' ',$post->video);
                                                    $video = '';
                                                    foreach($arrayVideo as $element){
                                                        if (strpos($element, 'src') !== false) {
                                                            $video = substr($element, 5, -1);
                                                            if (strpos($video, 'youtube') !== false) {
                                                                $videoArray = explode('/',$video);
                                                                $video = 'https://www.youtube.com/watch?v='.$videoArray[4];
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                    <a href="<?php echo e($video); ?>" class="css3animate popup-content popup-video text-center text-gray-800 d-flex justify-content-between align-items-center w-100">
                                                        <p class="m-0 text-capitalize"><?php echo e(__('content.video')); ?></p>
                                                        <div class="popup-content-hover css3animate">
                                                            <i class="fas fa-search-plus text-gray-100 css3animate"></i>
                                                        </div>
                                                    </a>
                                                <?php elseif($post->type == 'quote'): ?>
                                                    <div class="post-quote p-3 bg-secondary lh-sm">
                                                        <p class="fw-bold text-white mb-2"><?php echo e($post->quote_text); ?></p>
                                                        <p class="fst-italic m-0 text-white"><?php echo e($post->quote_author); ?></p>
                                                    </div>
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('/')); ?>/<?php echo e($post->image); ?>" class="css3animate popup-content popup-image text-center text-gray-800 d-flex justify-content-between align-items-center w-100">
                                                        <img class="img-fluid" src="<?php echo e(url('/')); ?>/<?php echo e($post->image); ?>" />
                                                        <div class="popup-content-hover css3animate">
                                                            <i class="fas fa-search-plus text-gray-100 css3animate"></i>
                                                        </div>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($post->status == 'pending'): ?>
                                                    <i class="far fa-clock h4 text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.pending')); ?>"></i>
                                                <?php else: ?>
                                                    <i class="far fa-thumbs-up h4 text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e(__('content.published')); ?>"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if($i < count($blog)): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/blog/posts/order-down/<?php echo e($post->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-down"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($i != 1): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/blog/posts/order-up/<?php echo e($post->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-up"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/blog/post/<?php echo e($post->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/blog/post')); ?>/<?php echo e($post->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deletePost<?php echo e($post->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deletePost<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_posts_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/admin/pages/blog/posts.blade.php ENDPATH**/ ?>