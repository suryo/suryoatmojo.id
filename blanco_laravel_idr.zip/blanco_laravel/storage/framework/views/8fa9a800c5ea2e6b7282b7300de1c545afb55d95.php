<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.sliders')); ?> - <?php echo e(__('content.images')); ?></h1>
        <a href="<?php echo e(url('/')); ?>/admin/sliders" class="css3animate btn btn-primary text-white">
            <i class="fas fa-angle-left mr-2"></i> <?php echo e(__('content.back')); ?>

        </a>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.images')); ?></h6>
                </div>
                <div class="card-body">
                    <?php if(count($slider_images) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width-25" scope="row">#</th>
                                        <th><?php echo e(__('content.image')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $slider_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i++); ?></th>
                                            <td>
                                                <a href="<?php echo e(asset('/')); ?>/<?php echo e($slider_image->image); ?>" class="css3animate popup-content popup-image text-center text-gray-800 d-flex justify-content-between align-items-center popup-image-big">
                                                    <img src="<?php echo e(asset('/')); ?>/<?php echo e($slider_image->image); ?>" class="img-fluid img-size-200" />
                                                    <div class="popup-content-hover css3animate">
                                                        <i class="fas fa-eye text-gray-100 css3animate"></i>
                                                    </div>
                                                </a>
                                            <td>
                                                <div class="btn-group">
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/sliders/images')); ?>/<?php echo e($slider_image->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteSlider<?php echo e($slider_image->id); ?>">
                                                            <i class="far fa-trash-alt mr-2"></i> <?php echo e(__('content.yes_delete')); ?>

                                                        </button>
                                                        <div class="modal fade" id="deleteSlider<?php echo e($slider_image->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                        <input type="hidden" name="slider_id" value="<?php echo e($slider_image->slider_id); ?>"/>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_sliders_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/sliders/images.blade.php ENDPATH**/ ?>