<section class="skills back-image pt-8 pb-9 py-5 <?php echo e($section->skills_scheme_color); ?>" 
    data-image="<?php echo e(!empty($section->skills_background) ? $section->skills_background : 'null'); ?>">
    <div class="container">
        
        <div class="row">
            <div class="col-12 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
            <?php if(!empty($section->skills_subtitle)): ?>
                <p class="mb-2 text-center accent-color fnt-bold"><?php echo e($section->skills_subtitle); ?></p>
            <?php endif; ?>
            <?php if(!empty($section->skills_title)): ?>
                <h2 class="m-0 my-3 mt-sm-0 text-center"><?php echo e($section->skills_title); ?></h2>
            <?php endif; ?>
            </div>
        </div>

        <div class="row">
            
            <?php if(count($design_skills)>0): ?>
            <div class="col-md-6 mt-4 mt-sm-5">
                <h3 class="d-flex align-items-center mb-4">
                    <i class="fas fa-paint-brush mb-0 me-2 h3 main-color"></i>
                    <?php echo e(__('content.skills_design')); ?>

                </h3>
                <div class="skills-design-content">
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $design_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bar <?php echo ($i < count($design_skills)) ? 'mb-3' : ''; $i++; ?>" data-percentage="<?php echo e($skill->percentage); ?>">
                        <p class="mb-1 css3animate"><?php echo e($skill->title); ?></p>
                        <p class="bar-percentage css3animate m-0 text-center"><?php echo e($skill->percentage); ?></p>
                        <div class="bar-graph">
                            <div class="main-layer"></div>
                            <div class="percent-layer general_bg"></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(count($dev_skills)>0): ?>
            <div class="col-md-6 mt-4 mt-sm-5">
                <h3 class="d-flex align-items-center mb-4">
                    <i class="fas fa-code mb-0 me-2 h3 main-color"></i>
                    <?php echo e(__('content.skills_development')); ?>

                </h3>
                <div class="skills-dev-content pt-2">
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $dev_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php  
                            $trackcolor = ($section->skills_scheme_color == 'light-scheme') ? $style->light_back_secondary_color : $style->dark_back_secondary_color ;
                            $barcolor = ($section->skills_scheme_color == 'light-scheme') ? $style->light_accent_color : $style->dark_accent_color ;
                        ?>
                        <div class="pie-chart <?php echo ($i < count($dev_skills)) ? 'mb-4 mb-md-5' : ''; $i++; ?>" data-percent="<?php echo e($skill->percentage); ?>" data-barcolor="<?php echo e($barcolor); ?>" data-trackcolor="<?php echo e($trackcolor); ?>">
                            <h2 class="percentage m-0 css3animate"><?php echo e($skill->percentage); ?></h2>
                            <p class="percentage-title css3animate fnt-bold m-0"><?php echo e($skill->title); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(count($edu_experiences)>0): ?>
            <div class="col-md-5 mt-4 mt-sm-5">
                <h3 class="d-flex align-items-center mb-4">
                    <i class="fas fa-briefcase mb-0 me-2 h3 main-color"></i>
                    <?php echo e(__('content.education')); ?>

                </h3>
                <div class="timeline d-flex pt-2">
                    <div class="cards">
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $edu_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card p-4 border shadow css3animate <?php echo ($i < count($edu_experiences)) ? 'mb-4' : ''; $i++; ?>">                          
                            <p class="card-date mb-2"><?php echo e($experience->period); ?></p>
                            <h4 class="mb-2 css3animate"><?php echo e($experience->title); ?></h4>
                            <p class="card-text mb-0"><?php echo e($experience->description); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>  
                </div>
            </div>
            <div class="col-md-1"></div>
            <?php endif; ?>

            <?php if(count($emp_experiences)>0): ?>
            <div class="col-md-5 mt-4 mt-sm-5">
                <h3 class="d-flex align-items-center mb-4">
                    <i class="fas fa-graduation-cap mb-0 me-2 h3 main-color"></i>
                    <?php echo e(__('content.employment')); ?>

                </h3>
                <div class="timeline d-flex pt-2">
                    <div class="cards">
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $emp_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card p-4 border shadow css3animate <?php echo ($i < count($emp_experiences)) ? 'mb-4' : ''; $i++; ?>">                          
                            <p class="card-date mb-2"><?php echo e($experience->period); ?></p>
                            <h4 class="mb-2 css3animate"><?php echo e($experience->title); ?></h4>
                            <p class="card-text mb-0"><?php echo e($experience->description); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>  
                </div>
            </div>
            <div class="col-md-1"></div>
            <?php endif; ?>

        </div>
    </div>
</section><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/sections/subsections/skills.blade.php ENDPATH**/ ?>