<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright © Blanco <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/admin/modules/footer.blade.php ENDPATH**/ ?>