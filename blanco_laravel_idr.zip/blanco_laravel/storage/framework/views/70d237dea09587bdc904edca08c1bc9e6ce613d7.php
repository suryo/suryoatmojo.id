<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(__('content.admin_panel')); ?></title>

    <!-- CSRF TOKEN -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">  
    <link href="<?php echo e(asset('assets/admin/img/favicon.png')); ?>" sizes="128x128" rel="shortcut icon" type="image/x-icon" />
    <link href="<?php echo e(asset('assets/admin/img/favicon.png')); ?>" sizes="128x128" rel="shortcut icon" />

    <!-- FONTS -->
    <link href="<?php echo e(asset('assets/fonts/fontawesome/css/all.min.css')); ?>" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Nunito:400,900 rel="stylesheet">

    <!-- STYLES -->
    <link href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/summernote-bs4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/admin.css')); ?>" rel="stylesheet">

</head>
<body>
    
    <div id="wrapper">
    
        <?php echo $__env->make('admin.modules.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('admin.modules.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php echo $__env->make('admin.modules.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>

<!-- JS LIBRARIES -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/sb-admin-2.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.dataTables.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/dataTables.bootstrap4.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.magnific-popup.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/summernote-bs4.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-select.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/purify.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('assets/admin/js/scripts.js')); ?>" defer></script>

</body>
</html><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/layouts/admin/main.blade.php ENDPATH**/ ?>