<div class="cookies-message p-4 <?php echo e($general->cookies_style); ?>">
	<div class="p-4 shadow text-<?php echo e($general->cookies_alignment); ?> <?php echo e($general->cookies_color); ?>">
		<?php if($general->cookies_title != ''): ?>
			<h3 class="mb-3"><?php echo e($general->cookies_title); ?></h3>
        <?php endif; ?>
        <?php if($general->cookies_text != ''): ?>
            <div class="cookies-message-content mb-3"><?php echo $general->cookies_text; ?></div>
        <?php endif; ?>
		<button type="button" class="btn m-0 cookies-close">
            <?php echo e(__('content.accept')); ?>

        </button>
	</div>
</div><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/fronted/sections/cookies.blade.php ENDPATH**/ ?>