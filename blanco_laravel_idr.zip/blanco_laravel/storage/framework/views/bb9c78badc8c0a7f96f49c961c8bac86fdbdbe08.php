<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.slider')); ?> <?php echo e($slider->id); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.edit_slider')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/').'/admin/sliders'); ?>/<?php echo e($slider->id); ?>" method="POST" class="slider-new user form-visibility" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="desc" class="form-label"><?php echo e(__('content.slider_type')); ?></label>
                                        <select class="form-select form-select-visibility" id="slider_type" name="slider_type" required>
                                            <option value="image" <?php echo e(($slider->type == 'image') ? 'selected' : ''); ?> data-visibility="image-options"><?php echo e(__('content.image')); ?></option>
                                            <option value="video" <?php echo e(($slider->type == 'video') ? 'selected' : ''); ?> data-visibility="video-options"><?php echo e(__('content.video')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                
                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.design')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="slider_overlay_color" class="form-label"><?php echo e(__('content.overlay_color')); ?></label>
                                    <div class="form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" data-visibility="overlay-color-options" name="slider_overlay_color" <?php echo e(($slider->overlay_color == 1) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="slider_overlay_color"><?php echo e(__('content.enable')); ?></label>
                                    </div>
                                </div>
                                <div class="row overlay-color-options <?php echo e(($slider->overlay_color == 0) ? 'd-none' : ''); ?>">
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="desc" class="form-label"><?php echo e(__('content.type')); ?></label>
                                            <select class="form-select" id="slider_overlay_type" name="slider_overlay_type">
                                                <option value="solid" <?php echo e(($slider->overlay_type == 'solid') ? 'selected' : ''); ?>><?php echo e(__('content.solid')); ?></option>
                                                <option value="gradient" <?php echo e(($slider->overlay_type == 'gradient') ? 'selected' : ''); ?>><?php echo e(__('content.gradient')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="slider_overlay_color_1" class="form-label"><?php echo e(__('content.color')); ?> 1</label>
                                            <input type="color" class="form-control form-control-color" name="slider_overlay_color_1" value="<?php echo e($slider->color_1); ?>" title="Choose your color" required />
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3 overlay-color-2-options <?php echo e(($slider->overlay_type == 'solid') ? 'd-none' : ''); ?>">
                                        <div class="form-group">
                                            <label for="slider_overlay_gradient_type" class="form-label"><?php echo e(__('content.gradient_type')); ?></label>
                                            <select class="form-select" id="slider_overlay_gradient_type" name="slider_overlay_gradient_type">
                                                <option value="0" <?php echo e(($slider->gradient_type == '0') ? 'selected' : ''); ?>><?php echo e(__('content.0_degree')); ?></option>
                                                <option value="45" <?php echo e(($slider->gradient_type == '45') ? 'selected' : ''); ?>><?php echo e(__('content.45_degree')); ?></option>
                                                <option value="90" <?php echo e(($slider->gradient_type == '90') ? 'selected' : ''); ?>><?php echo e(__('content.90_degree')); ?></option>
                                                <option value="-45" <?php echo e(($slider->gradient_type == '-45') ? 'selected' : ''); ?>><?php echo e(__('content.45_degree_b')); ?></option>
                                                <option value="radial" <?php echo e(($slider->gradient_type == 'radial') ? 'selected' : ''); ?>><?php echo e(__('content.radial')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3 overlay-color-2-options <?php echo e(($slider->overlay_type == 'solid') ? 'd-none' : ''); ?>">
                                        <div class="form-group">
                                            <label for="slider_overlay_color_2" class="form-label"><?php echo e(__('content.color')); ?> 2</label>
                                            <input type="color" class="form-control form-control-color" name="slider_overlay_color_2" value="<?php echo e($slider->color_2); ?>" title="Choose your color" required />
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.text')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="desc" class="form-label"><?php echo e(__('content.color_scheme')); ?></label>
                                        <select class="form-select" id="slider_color" name="slider_scheme_color">
                                            <option value="light-scheme" <?php echo e(($slider->color_scheme == 'light-scheme') ? 'selected' : ''); ?>><?php echo e(__('content.light')); ?></option>
                                            <option value="dark-scheme" <?php echo e(($slider->color_scheme == 'dark-scheme') ? 'selected' : ''); ?>><?php echo e(__('content.dark')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="slider_text_rotator" class="form-label"><?php echo e(__('content.slider_rotator')); ?></label>
                                    <div class="form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="slider_text_rotator" name="slider_text_rotator" <?php echo e(($slider->text_rotator == 1) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="slider_text_rotator"><?php echo e(__('content.enable')); ?></label>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3 slider-text">
                                    <div class="form-group mb-3">
                                        <label for="slider_text" class="form-label"><?php echo e(__('content.text')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['slider_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"" id="slider_text" name="slider_text" rows="3" required><?php echo e($slider->text); ?></textarea>
                                        <div class="form-text">
                                            <span><?php echo e(__('content.line_breaks')); ?></span>
                                        </div>
                                        <div class="form-text">
                                            <span><?php echo e(__('content.line_jump')); ?></span>
                                        </div>
                                        <div class="form-text">
                                            <span><?php echo e(__('content.line_mark')); ?></span>
                                        </div>
                                        <?php $__errorArgs = ['slider_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3 slider-text-rotator <?php echo e(($slider->text_rotator == 0) ? 'd-none' : ''); ?>">
                                    <div class="form-group">
                                        <label for="slider_interval_rotator" class="form-label"><?php echo e(__('content.slider_interval_rotator')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"" type="number" min="500" max="5000" step="100" id="slider_interval_rotator" name="slider_interval_rotator" value="<?php echo e($slider->text_rotator_interval); ?>" />
                                        <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.number_not_valid')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3 slider-text-rotator <?php echo e(($slider->text_rotator == 0) ? 'd-none' : ''); ?>">
                                    <div class="form-group">
                                        <label for="slider_text_animation_in" class="form-label"><?php echo e(__('content.animation_in')); ?></label>
                                        <select class="form-select" id="slider_text_animation_in" name="slider_text_animation_in">
                                            <option value="none" <?php echo e(($slider->animation_in == "none") ? 'selected' : ''); ?>><?php echo e(__('content.none')); ?></option>
                                            <?php $__currentLoopData = $animations_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($animation); ?>" <?php echo e(($slider->animation_in == $animation) ? 'selected' : ''); ?>><?php echo e(Str::substr($animation, 9)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3 slider-text-rotator <?php echo e(($slider->text_rotator == 0) ? 'd-none' : ''); ?>">
                                    <div class="form-group">
                                        <label for="slider_text_animation_out" class="form-label"><?php echo e(__('content.animation_out')); ?></label>
                                        <select class="form-select" id="slider_text_animation_out" name="slider_text_animation_out">
                                            <option value="none" <?php echo e(($slider->animation_out == "none") ? 'selected' : ''); ?>><?php echo e(__('content.none')); ?></option>
                                            <?php $__currentLoopData = $animations_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($animation); ?>" <?php echo e(($slider->animation_out == $animation) ? 'selected' : ''); ?>><?php echo e(Str::substr($animation, 9)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="row row-visibility video-options <?php echo ($slider->type == 'image') ? 'd-none' : ''; ?>">
                                <div class="col-12 mb-2">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.video')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3 slider-video-type">
                                    <div class="form-group">
                                        <label for="desc" class="form-label"><?php echo e(__('content.slider_video_type')); ?></label>
                                        <select class="form-select" id="slider_video_type" name="slider_video_type">
                                            <option value="server" <?php echo e(($slider->video_type == 'server') ? 'selected' : ''); ?>><?php echo e(__('content.server')); ?></option>
                                            <option value="youtube" <?php echo e(($slider->video_type == 'youtube') ? 'selected' : ''); ?>>Youtube</option>
                                            <option value="vimeo" <?php echo e(($slider->video_type == 'vimeo') ? 'selected' : ''); ?>>Vimeo</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6"></div>
                                <div class="col-md-6 mb-3 slider-video">
                                    <div class="form-group video-server <?php echo e(($slider->video_type != 'server') ? 'd-none' : ''); ?>">
                                        <label for="slider_server_video" class="form-label w-100"><?php echo e(__('content.slider_video_server')); ?>

                                        <?php if($slider->type == 'video' && $slider->video_type == 'server'): ?>
                                            <span class="float-end fst-italic fw-normal text-success"><?php echo e(__('content.current_video')); ?> <?php echo e(Str::substr($slider->video, 23)); ?></span>
                                        <?php endif; ?>
                                        </label>
                                        <input class="form-control" type="file" id="slider_server_video" name="slider_server_video" />
                                        <input type="hidden" name="slider_server_video_current" value="<?php echo e($slider->video); ?>" />
                                        <div class="form-text"><?php echo e(__('content.video_server_requirements')); ?></div>
                                        <div class="invalid-feedback d-none">
                                            <?php echo e(__('content.required')); ?>

                                        </div>
                                    </div>
                                    <div class="form-group video-url <?php echo e(($slider->video_type == 'server') ? 'd-none' : ''); ?>">
                                        <label for="slider_url_video" class="form-label"><?php echo e(__('content.slider_video_url')); ?>

                                        </label>
                                        <input class="form-control" type="text" id="slider_url_video" name="slider_url_video" value="<?php echo e($slider->video); ?>"/>
                                        <div class="form-text"><?php echo e(__('content.video_url_requirements')); ?></div>
                                        <div class="invalid-feedback d-none">
                                            <?php echo e(__('content.required')); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="image_video" class="form-label d-flex justify-content-between">
                                            <?php echo e(__('content.image_replaced')); ?>

                                            <span class="fw-normal fst-italic remove-image text-primary" data-target="image_video" data-url="<?php echo e(asset('/')); ?>"><i class="fas fa-times mr-1"></i><?php echo e(__('content.remove_image')); ?></span>
                                        </label>
                                        <?php
                                            $imgVideoUrl = ($slider->image_video != '') ? $slider->image_video : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgVideoUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_video" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_video" value=""/>
                                        <input type="hidden" name="image_video_current" value="<?php echo e($slider->image_video); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 160x160px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" id="submitSliderBtn">
                                <?php echo e(__('content.update')); ?>

                            </button>
                            <a href="<?php echo e(url('/')); ?>/admin/sliders">
                                <button type="button" class="btn btn-secondary"><?php echo e(__('content.cancel')); ?></button>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/sliders/single.blade.php ENDPATH**/ ?>