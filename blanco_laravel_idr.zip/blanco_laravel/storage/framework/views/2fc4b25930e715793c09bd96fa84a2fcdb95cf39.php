<?php $__env->startSection('title', trans('installer_messages.welcome.title')); ?>
<?php $__env->startSection('container'); ?>
    <h3 class="my-2 text-center text-gray-900 fw-bold"><?php echo e(trans('installer_messages.welcome.title')); ?></h3>
    <div class="modal-footer d-flex justify-content-center border-0">
        <a href="<?php echo e(route('LaravelInstaller::environment')); ?>" class="btn btn-primary mt-3"><?php echo e(trans('installer_messages.next')); ?></a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/vendor/installer/welcome.blade.php ENDPATH**/ ?>