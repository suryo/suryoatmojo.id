<div class="pt-page back-image work pt-12 pt-7 pb-4 <?php echo e($section->projects_scheme_color); ?>" data-colorScheme="<?php echo e($section->projects_scheme_color); ?>" data-overflow="1">
    <section class="back-image pb-8 pb-5" data-image="<?php echo e(!empty($section->projects_background) ? $section->projects_background : 'null'); ?>">
        <div class="container">

            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3 mb-4">
                <?php if(!empty($section->projects_subtitle)): ?>
                    <p class="mb-2 text-center accent-color fnt-bold"><?php echo e($section->projects_subtitle); ?></p>
                <?php endif; ?>
                <?php if(!empty($section->projects_title)): ?>
                    <h2 class="m-0 my-3 mt-sm-0 text-center"><?php echo e($section->projects_title); ?></h2>
                <?php endif; ?>
                </div>
            </div>

            <?php if(count($projects)>0): ?>
            <div class="row">
                    
                <div class="col-12 mt-4">
                    <div id="filters" class="text-center">
                        <button class="btn btn-outline-secondary css3animate checked rounded-0 py-2 px-4 mx-1 mb-2" data-filter="*"><?php echo e(__('content.all')); ?></button>
                        <?php $__currentLoopData = $projects_categories_filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-outline-secondary css3animate rounded-0 py-2 px-4 mx-1 mb-2" data-filter=".<?php echo e($filter); ?>"><?php echo e(Str::upper($filter)); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-12 my-4 projects-content" data-route="<?php echo e(url('/')); ?>" data-style="<?php echo e($section->projects_style); ?>">
                    <div id="gallery">
                        <div class="grid-sizer"></div>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $projects_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($project->category_id == $category->id): ?>
                                <div class="item <?php echo e($category->name); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a class="pt-trigger css3animate menu-hide project-call text-decoration-none p-0" href="#" data-id="<?php echo e($project->id); ?>" data-animation="19" data-goto="" data-image="<?php echo e($project->image); ?>" data-height="<?php echo e($projects_masonry[$i]); ?>">
                                <img src="<?php echo e(url('/')); ?>/<?php echo e($project->image); ?>" alt="<?php echo e($project->title); ?>" />
                                <div class="project-text p-4 p-lg-5 style-<?php echo e($section->projects_style); ?>">
                                    <h3 class="css3animate mb-3 text-white"><?php echo e($project->title); ?></h3>
                                    <p class="css3animate m-0 text-white"><?php echo e($project->short_desc); ?></p>
                                </div>
                            </a>
                        </div>
                        <?php
                        if ($i < 5) {
                            $i++;    
                        } else {
                            $i = 0;
                        } ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
            <?php endif; ?>

        </div>
    </section>
</div>

<div class="pt-page work-project py-5 <?php echo e($section->projects_scheme_color); ?>" data-overflow="1">
    <section class="container py-3 py-lg-5 mt-lg-4">
        <div class="row project-title-container d-flex align-items-center flex-column-reverse flex-lg-row">
            <div class="col-12 col-lg-6 mb-4 mb-lg-5">
                <h2 class="project-title pe-lg-5 m-0 text-center text-lg-start hide-element"></h2>
            </div>
            <div class="col-12 col-lg-6 d-flex justify-content-center justify-content-lg-end mb-3 mb-lg-5">
                <button class="pt-trigger css3animate rounded-circle menu-show project-hide" data-animation="20" data-goto="" data-style="<?php echo e($section->projects_scheme_color); ?>">
                    <span class="d-block"></span>
                    <span class="d-block"></span>
                </button>
            </div>
        </div>
        <div class="row project-media hide-element mt-4"></div>

        <div class="row mt-4 mt-lg-5 flex-column-reverse flex-lg-row">
            <div class="col-12 col-lg-8 project-content content-text hide-element mt-4"></div>
            <div class="col-12 col-lg-4 project-information hide-element mt-2 mt-lg-4"></div>
        </div>

        <div class="row mt-4 mt-lg-5 project-gallery hide-element" data-title="<?php echo e(__('content.gallery')); ?>"></div>

        <div class="work-script"></div>

    </section>
</div><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/sections/projects.blade.php ENDPATH**/ ?>