<?php $__env->startSection('title', trans('installer_messages.permissions.title')); ?>
<?php $__env->startSection('container'); ?>
    <?php if(isset($permissions['errors'])): ?>
        <div class="alert alert-danger">Please fix the below error and the click  <?php echo e(trans('installer_messages.checkPermissionAgain')); ?></div>
    <?php endif; ?>
    <ul class="list p-0 m-0">
        <?php $__currentLoopData = $permissions['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="item px-2 mb-3 <?php echo e($permission['isSet'] ? 'success' : 'error'); ?>">
            <?php if($permission['isSet']): ?>
                <i class="fa-regular fa-circle-check"></i>
            <?php else: ?>
                <i class="fa-regular fa-circle-xmark"></i>
            <?php endif; ?>
            <?php echo e($permission['folder']); ?><span><?php echo e($permission['permission']); ?></span>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    <div class="modal-footer d-flex justify-content-center border-0">
        <?php if( ! isset($permissions['errors'])): ?>
            <a class="btn btn-primary animate" href="<?php echo e(route('LaravelInstaller::database')); ?>" id="permission-button">
                <?php echo e(trans('installer_messages.next')); ?>

            </a>
            <i class="fa-solid fa-spinner spinner-rotate hidden animate" id="permission-spinner"></i>
        <?php else: ?>
            <a class="btn btn-primary" href="javascript:window.location.href='';">
                <?php echo e(trans('installer_messages.checkPermissionAgain')); ?>

            </a>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script>
        $('#permission-button').on('click', function() {
            $(this).addClass('hidden');
            setTimeout(function() {
                $('#permission-spinner').removeClass('hidden');
            }, 500);
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/vendor/installer/permissions.blade.php ENDPATH**/ ?>