<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.profile_settings')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e($user->name); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/').'/admin/profile'); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="name" class="form-label"><?php echo e(__('content.name')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e($user->name); ?>" />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="email" class="form-label"><?php echo e(__('content.email')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" value="<?php echo e($user->email); ?>" />
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.email_not_valid')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="image_profile" class="form-label"><?php echo e(__('content.image')); ?></label>
                                        <?php
                                            $imgProfileUrl = ($user->image != '') ? $user->image : 'uploads/img/image_default.png';
                                        ?>
                                        <div class="d-flex p-3 mb-3 bg-gray-200 justify-content-center">
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $imgProfileUrl; ?>" class="img-fluid img-maxsize-200 previewImage_image_profile" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image_profile" value=""/>
                                        <input type="hidden" name="image_profile_current" value="<?php echo e($user->image); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 50x50px</span>
                                        </div>
                                        <?php $__errorArgs = ['image_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold mb-3"><?php echo e(__('content.change_password')); ?></h4>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="pass_current" class="form-label"><?php echo e(__('content.pass_current')); ?></label>
                                        <div class="form-password">
                                            <input class="form-control 
                                                <?php $__errorArgs = ['pass_current'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php if(Session::has('error-validation-pass-current')): ?> is-invalid <?php endif; ?>" 
                                                type="password" name="pass_current" value="" />
                                            <i class="far fa-eye password-option password-visible css3animate"></i>
                                            <i class="far fa-eye-slash password-option password-hidden css3animate d-none"></i>
                                        </div>
                                        <?php $__errorArgs = ['pass_current'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_required')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php if(Session::has('error-validation-pass-current')): ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_not_valid')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3"></div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="pass_new_1" class="form-label"><?php echo e(__('content.pass_new_1')); ?></label>
                                        <div class="form-password">
                                            <input class="form-control 
                                                <?php $__errorArgs = ['pass_new_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php if(Session::has('error-validation-new-pass')): ?> is-invalid <?php endif; ?>" 
                                                type="password" name="pass_new_1" value="" />
                                            <i class="far fa-eye password-option password-visible css3animate"></i>
                                            <i class="far fa-eye-slash password-option password-hidden css3animate d-none"></i>
                                        </div>
                                        <div id="passwordHelpBlock" class="form-text">
                                            Password: must be at least 10 characters in length and contain at least one lowercase and uppercase letter, one digit and a special character: @$!%*#?&-_
                                        </div>
                                        <?php $__errorArgs = ['pass_new_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_required')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php if(Session::has('error-validation-new-pass')): ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_not_same')); ?> 
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="pass_new_2" class="form-label"><?php echo e(__('content.pass_new_2')); ?></label>
                                        <div class="form-password">
                                            <input class="form-control 
                                                <?php $__errorArgs = ['pass_new_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php if(Session::has('error-validation-new-pass')): ?> is-invalid <?php endif; ?>" 
                                                type="password" name="pass_new_2" value="" />
                                            <i class="far fa-eye password-option password-visible css3animate"></i>
                                            <i class="far fa-eye-slash password-option password-hidden css3animate d-none"></i>
                                        </div>
                                        <div id="passwordHelpBlock" class="form-text">
                                            Password: must be at least 10 characters in length and contain at least one lowercase and uppercase letter, one digit and a special character: @$!%*#?&-_
                                        </div>
                                        <?php $__errorArgs = ['pass_new_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_required')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php if(Session::has('error-validation-new-pass')): ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.password_not_same')); ?> 
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/profile.blade.php ENDPATH**/ ?>