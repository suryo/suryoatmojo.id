<?php 
if ($slider->type == 'image'):
    echo '
    <div class="slider-content" data-interval="'.$slider->text_rotator_interval.'" data-number="'.count($slider_images).'"';
        $i=1;
        foreach ($slider_images as $image):
            echo ' data-image-'.$i.'="'.$image->image.'" ';
            $i++;
        endforeach;
    echo '
    ></div>';
endif;
?>
<div class="pt-page css3animate p-0 homepage d-flex justify-content-center align-items-center <?php echo e($slider->color_scheme); ?>" data-colorScheme="<?php echo e($slider->color_scheme); ?>" data-overflow="0" 
    data-overlayColor="<?php echo e($slider->overlay_color); ?>"
    data-overlayType="<?php echo e($slider->overlay_type); ?>"
    data-overlayColor1="<?php echo e($slider->color_1); ?>"
    data-overlayColor2="<?php echo e($slider->color_2); ?>"
    data-overlayGradient="<?php echo e($slider->gradient_type); ?>">
    <?php if($slider->text != ''): ?>
    <section>
        <div class="container">
            <div class="row">
                <?php
                $texts = preg_split( "/\\r\\n|\\r|\\n/", $slider->text ); ?>
                <div id="messages-content">
                    <div class="col-lg-10 offset-lg-1 messages" 
                        data-textrotator="<?php echo e($slider->text_rotator); ?>" 
                        data-interval="<?php echo e($slider->text_rotator_interval); ?>"
                        data-number="<?php echo (count($texts)>1) ? 1 : 0; ?>"
                        data-animationin="<?php echo e($slider->animation_in); ?>"
                        data-animationout="<?php echo e($slider->animation_out); ?>">
                        
                        <?php
                        $texts = str_replace("/*", "<span class='underlined'>", $texts);
                        $texts = str_replace("*/", "</span>", $texts);
                            if ($slider->text_rotator == 1){
                                foreach ($texts as $text):
                                    echo'
                                    <div class="animate__animated animate__bounceOut">
                                        <h2 class="m-0 text-center">'.$text.'</h2>
                                    </div>';
                                endforeach;
                            } else {
                                if (is_array($texts)){
                                    $texts = $texts[0];
                                }
                                echo'
                                <div class="animate__animated animate__bounceOut">
                                    <h2 class="m-0 text-center">'.$texts.'</h2>
                                </div>';
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php if($slider->type == 'video'): ?>      
        <div class="video-controls">
            <button id="play_video"><i class="fas fa-play"></i></button>
            <button id="pause_video"><i class="fas fa-pause"></i></button>
            <button id="mute_video" class="d-none"><i class="fas fa-volume-mute"></i></button>
            <button id="unmute_video"><i class="fas fa-volume-up"></i></button>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/sections/home.blade.php ENDPATH**/ ?>