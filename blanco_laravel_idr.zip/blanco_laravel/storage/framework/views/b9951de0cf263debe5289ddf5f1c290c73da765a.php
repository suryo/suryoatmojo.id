<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.testimonial_of')); ?>: <?php echo e($testimonial->name); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.edit_testimonial')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/').'/admin/testimonials'); ?>/<?php echo e($testimonial->id); ?>" method="POST" class="user" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <input type="hidden" name="order" value="<?php echo e($testimonial->order); ?>" />
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label"><?php echo e(__('content.name')); ?></label>
                                    <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e($testimonial->name); ?>" required />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="company" class="form-label"><?php echo e(__('content.company')); ?></label>
                                    <input class="form-control <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="company" value="<?php echo e($testimonial->company); ?>" required />
                                    <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="text" class="form-label"><?php echo e(__('content.text')); ?></label>
                                    <textarea class="form-control <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="text" rows="4" required><?php echo e($testimonial->text); ?></textarea>
                                    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="image" class="form-label"><?php echo e(__('content.image')); ?></label>
                                        <div class="d-flex p-3 mb-2 bg-gray-200 justify-content-center">
                                            <?php
                                                if ($testimonial->image != ''):
                                                    $image_link = $testimonial->image;
                                                else:
                                                    $image_link = 'uploads/img/image_default.png';
                                                endif;
                                            ?>
                                            <img src="<?php echo e(asset('/')); ?>/<?php echo $image_link ?>" class="img-fluid img-maxsize-200 previewImage_image" />
                                        </div>
                                        <input class="form-control previewImage <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image" value="" />
                                        <input type="hidden" name="image_current" value="<?php echo e($testimonial->image); ?>" />
                                        <div class="form-text d-flex justify-content-between">
                                            <span><?php echo e(__('content.image_requirements')); ?></span>
                                            <span><?php echo e(__('content.image_size_recommended')); ?> 550x950px</span>
                                        </div>
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.error_validation_image')); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                            <a href="<?php echo e(url('/')); ?>/admin/testimonials">
                                <button type="button" class="btn btn-secondary"><?php echo e(__('content.cancel')); ?></button>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/testimonials/single.blade.php ENDPATH**/ ?>