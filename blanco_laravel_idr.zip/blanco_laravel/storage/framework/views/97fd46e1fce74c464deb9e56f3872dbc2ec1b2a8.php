<?php $__env->startSection('title', trans('installer_messages.environment.title')); ?>
<?php $__env->startSection('container'); ?>
    <form action="<?php echo e(route('LaravelInstaller::environmentSave')); ?>" id="env-form" method="post" class="row">
        <?php echo csrf_field(); ?>
        <div class="form-group col-12 col-md-6">
            <label class="control-label">Hostname</label>
            <input type="text" name="hostname" class="form-control" >
        </div>
        <div class="form-group col-12 col-md-6">
            <label class="control-label">Database</label>
            <input type="text" name="database" class="form-control">
        </div>
        <div class="form-group col-12 col-md-6">
            <label class="control-label">Username</label>
            <input type="text" name="username" class="form-control">
        </div>
        <div class="form-group col-12 col-md-6">
            <label class="control-label">Password</label>
            <input type="password" class="form-control" name="password">
        </div>
        <div class="modal-footer d-flex justify-content-center border-0">
            <button class="btn btn-primary" onclick="checkEnv();return false">
                <?php echo e(trans('installer_messages.next')); ?>

            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/installer.min.js')); ?>"></script>
    <script>
        function checkEnv() {
            $.easyAjax({
                url: "<?php echo route('LaravelInstaller::environmentSave'); ?>",
                type: "GET",
                data: $("#env-form").serialize(),
                container: "#env-form",
                messagePosition: "inline"
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/vendor/installer/environment.blade.php ENDPATH**/ ?>