<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>
    <p><strong>{{__('content.name')}}:</strong><br>{{ $data['name'] }}</p>
    <p><strong>{{__('content.email')}}:</strong><br>{{ $data['email'] }}</p>
    <p><strong>{{__('content.message')}}:</strong><br>{{ $data['message'] }}</p>
</body>
</html>