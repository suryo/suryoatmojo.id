<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.experiences')); ?></h1>
        <button type="button" class="btn btn-primary btn-round d-inline" data-bs-toggle="modal" data-bs-target="#experienceNewModal">
            <i class="fas fa-plus small"></i>
            <?php echo e(__('content.add_experience')); ?>

        </button>
    </div>

    <div class="row">
        
        
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.edu_experiences')); ?></h6>
                </div>
                <div class="card-body">
                    <?php if(count($edu_experiences) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.title')); ?></th>
                                        <th><?php echo e(__('content.period')); ?></th>
                                        <th><?php echo e(__('content.description')); ?></th>
                                        <th><?php echo e(__('content.order')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $edu_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu_experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($edu_experience->title); ?></td>
                                            <td><?php echo e($edu_experience->period); ?></td>
                                            <td><?php echo e($edu_experience->description); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if($i < count($edu_experiences)): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/experiences/order-down/<?php echo e($edu_experience->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-down"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($i != 1): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/experiences/order-up/<?php echo e($edu_experience->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-up"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/experiences/<?php echo e($edu_experience->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/experiences')); ?>/<?php echo e($edu_experience->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteExperience<?php echo e($edu_experience->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deleteExperience<?php echo e($edu_experience->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_experiences_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.emp_experiences')); ?></h6>
                </div>
                <div class="card-body">
                    <?php if(count($emp_experiences) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.title')); ?></th>
                                        <th><?php echo e(__('content.period')); ?></th>
                                        <th><?php echo e(__('content.description')); ?></th>
                                        <th><?php echo e(__('content.order')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $j = 1; ?>
                                    <?php $__currentLoopData = $emp_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp_experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($j); ?></td>
                                            <td><?php echo e($emp_experience->title); ?></td>
                                            <td><?php echo e($emp_experience->period); ?></td>
                                            <td><?php echo e($emp_experience->description); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if($j < count($emp_experiences)): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/experiences/order-down/<?php echo e($emp_experience->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-down"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($j != 1): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/experiences/order-up/<?php echo e($emp_experience->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-up"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/experiences/<?php echo e($emp_experience->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/experiences')); ?>/<?php echo e($emp_experience->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteExperience<?php echo e($emp_experience->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deleteExperience<?php echo e($emp_experience->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $j++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_experiences_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- MODAL TO CREATE A NEW EMPLOYMENT EXPERIENCE -->
<div class="modal fade" id="experienceNewModal" tabindex="-1" role="dialog" aria-labelledby="experienceNewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('content.new_experience')); ?></h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('/').'/admin/experiences'); ?>" method="POST" class="user">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" name="order_edu" value="<?php echo (count($edu_experiences) > 0) ? $i : 1; ?>" />
                        <input type="hidden" name="order_emp" value="<?php echo (count($emp_experiences) > 0) ? $j : 1; ?>" />
                        <div class="col-md-12 mb-3">
                            <label for="type" class="form-label"><?php echo e(__('content.type')); ?></label>
                            <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type">
                                <option value="education"><?php echo e(__('content.education')); ?></option>
                                <option value="employment"><?php echo e(__('content.employment')); ?></option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                            <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" required value="<?php echo e(old('title')); ?>" />
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="period" class="form-label"><?php echo e(__('content.period')); ?></label>
                            <input class="form-control <?php $__errorArgs = ['period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="period" required value="<?php echo e(old('period')); ?>" />
                            <?php $__errorArgs = ['period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="description" class="form-label"><?php echo e(__('content.description')); ?></label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" rows="4"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('content.add')); ?>

                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('content.close')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if(Session::has('error-modal')): ?>
    <input class="openModal" data-id="experienceNewModal" type="hidden" val="1" />
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/admin/pages/experiences/experiences.blade.php ENDPATH**/ ?>