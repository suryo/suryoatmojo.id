<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>
    <p><strong><?php echo e(__('content.name')); ?>:</strong><br><?php echo e($data['name']); ?></p>
    <p><strong><?php echo e(__('content.email')); ?>:</strong><br><?php echo e($data['email']); ?></p>
    <p><strong><?php echo e(__('content.message')); ?>:</strong><br><?php echo e($data['message']); ?></p>
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/fronted/sections/email.blade.php ENDPATH**/ ?>