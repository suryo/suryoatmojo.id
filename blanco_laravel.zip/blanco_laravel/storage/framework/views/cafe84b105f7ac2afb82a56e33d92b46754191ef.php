<?php $__env->startSection('content'); ?>

<?php if($section->slider_enable == 1): ?>
    <div id="pattern"></div>
<?php endif; ?>

<div class="pt-wrapper">

    
    <?php if($general->loader == true): ?>
        <?php echo $__env->make('fronted.sections.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($section->slider_enable == 1 && $slider != null): ?>
        <?php if($slider->type == 'video'): ?>      
            <div id="bgimg" data-video="<?php echo e($slider->video); ?>" data-poster="<?php echo e($slider->image_video); ?>"></div>
        <?php endif; ?>
        <?php if($slider->type == 'video' && $slider->video_type == 'youtube'): ?>  
            <div id="video-content"></div>
            <a id="bgndVideo" data-property="{videoURL:'<?php echo e($slider->video); ?>', containment:'#video-content', autoPlay:true, mute:true, startAt:0, opacity:1, ratio:'auto', addRaster:true}" data-poster="<?php echo e($slider->image_video); ?>"></a>    
        <?php endif; ?>
        <?php if($slider->type == 'video' && $slider->video_type == 'vimeo'): ?> 
            <?php    
                $vimeoArray = explode('/',$slider->video);
                $vimeoCode = $vimeoArray[count($vimeoArray)-1];
            ?> 
            <div id="video-content"></div>
            <div id="video" class="player" data-property="{videoURL:'<?php echo e($vimeoCode); ?>', containment:'#video-content', align:'bottom,center', showControls:false, autoPlay:true, loop:true, mute:true, startAt:0, addRaster:true}" data-poster="<?php echo e($slider->image_video); ?>"></div>
        <?php endif; ?>
    <?php endif; ?>
    
    
    <?php echo $__env->make('fronted.sections.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php if($section->slider_enable == 1 && $slider != null): ?>
        <?php echo $__env->make('fronted.sections.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->about_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->projects_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->blog_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->contact_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($general->cookies_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php echo $__env->make('fronted.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- END PT-WRAPPER  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fronted.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/index.blade.php ENDPATH**/ ?>