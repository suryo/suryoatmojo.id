<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.categories')); ?></h1>
    </div>

    <div class="row">
        
        
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.categories')); ?></h6>
                    <button type="button" class="btn btn-primary btn-round d-inline" data-bs-toggle="modal" data-bs-target="#categoryNewModal">
                        <i class="fas fa-plus small"></i>
                        <?php echo e(__('content.add_category')); ?>

                    </button>
                </div>
                <div class="card-body">
                    <?php if(count($categories) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.name')); ?></th>
                                        <th><?php echo e(__('content.slug')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td><?php echo e($category->slug); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/blog/categories/<?php echo e($category->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/blog/categories')); ?>/<?php echo e($category->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteCategory<?php echo e($category->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deleteCategory<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_categories_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- MODAL TO CREATE A NEW CATEGORY -->
<div class="modal fade " id="categoryNewModal" tabindex="-1" role="dialog" aria-labelledby="categoryNewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-min" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('content.new_category')); ?></h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('/').'/admin/blog/categories'); ?>" method="POST" class="user">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="name" class="form-label"><?php echo e(__('content.name')); ?></label>
                            <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" required value="<?php echo e(old('name')); ?>" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('content.add')); ?>

                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('content.close')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if(Session::has('error-modal')): ?>
    <input class="openModal" data-id="categoryNewModal" type="hidden" val="1" />
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/blog/categories.blade.php ENDPATH**/ ?>