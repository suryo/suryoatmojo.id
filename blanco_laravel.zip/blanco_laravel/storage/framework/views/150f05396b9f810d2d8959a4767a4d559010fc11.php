<div class="pt-page back-image blog pt-12 pt-7 pb-4 <?php echo e($section->blog_scheme_color); ?>" data-colorScheme="<?php echo e($section->blog_scheme_color); ?>" data-overflow="1">
    <section class="back-image pb-5" data-image="<?php echo e(!empty($section->blog_background) ? $section->blog_background : 'null'); ?>">
        <div class="container">

            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                <?php if(!empty($section->blog_subtitle)): ?>
                    <p class="mb-2 text-center accent-color fnt-bold"><?php echo e($section->blog_subtitle); ?></p>
                <?php endif; ?>
                <?php if(!empty($section->blog_title)): ?>
                    <h2 class="m-0 my-3 mt-sm-0 text-center"><?php echo e($section->blog_title); ?></h2>
                <?php endif; ?>
                </div>
            </div>

            <?php if(count($blog)>0): ?>
            <div class="row blog-content py-4 py-md-5" data-route="<?php echo e(url('/')); ?>">
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($loop->first): ?>
                        <div class="col-12 <?php echo e(($section->blog_columns == 3) ? 'col-lg-8' : ''); ?> mb-4 main-post-image">
                    <?php else: ?> 
                        <div class="col-12 col-md-6 col-lg-<?php echo e(12/$section->blog_columns); ?> mb-4">
                    <?php endif; ?>

                    <div class="post-content-container shadow-blanco">
                        <?php switch($post->type):
                            case ('standard'): ?>
                                <div class="post-image">
                                    <img src="<?php echo e($post->image); ?>" class="img-fluid w-100" alt="<?php echo e($post->title); ?>"/>
                                </div>
                                <?php break; ?>

                            <?php case ('gallery'): ?>
                                <div class="post-gallery">
                                    <div id="gallery-<?php echo e($post->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                        <!-- Indicators -->
                                        <ol class="carousel-indicators">
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($image->blog_id == $post->id): ?>
                                                    <li data-bs-target="#gallery-<?php echo e($post->id); ?>" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo ($i == 0) ? 'active' : ''; ?>"></li>
                                                    <?php $i++; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                        <!-- Wrapper for slides -->
                                        <div class="carousel-inner" role="listbox">
                                            <?php $j = 0 ?>
                                            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($image->blog_id == $post->id): ?>
                                                    <div class="carousel-item <?php echo ($j == 0) ? 'active' : ''; ?>">
                                                        <img src="<?php echo e($image->image); ?>" class="d-block w-100" alt="<?php echo e($post->title); ?>">
                                                    </div>    
                                                    <?php $j++; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php break; ?>

                            <?php case ('video'): ?>
                                <div class="post-video">
                                    <?php echo $post->video; ?>

                                </div>
                                <?php break; ?>

                            <?php case ('quote'): ?>
                                <div class="post-quote px-5 d-flex flex-column justify-content-center">
                                    <h3 class="mb-3"><?php echo e($post->quote_text); ?></h3>
                                    <p class="m-0">- <?php echo e($post->quote_author); ?></p>
                                </div>
                                <?php break; ?>

                        <?php endswitch; ?>

                        <?php if($loop->first): ?>
                            <a href="<?php echo e(url('/post').'/'.$post->slug); ?>" class="menu-hide main-post <?php echo e(($section->blog_title == 3) ? '' : 'main-post-wide'); ?> text-decoration-none d-flex flex-column justify-content-center justify-content-lg-start">
                        <?php else: ?> 
                            <div class="post-content">
                        <?php endif; ?>

                            <p class="info-post mb-2 fnt-small">
                                <?php
                                    $newtime = strtotime($post->created_at);    
                                    echo date('M d, Y',$newtime);
                                ?> 
                                <span class="mx-1">|</span>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($post->category_id == $category->id): ?>
                                        <?php echo e($category->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <h4 class="mb-3"><?php echo e($post->title); ?></h4>
                            <p class="m-0 info-description"><?php echo e($post->short_desc); ?></p>
                            
                            <?php if(!$loop->first): ?>
                            <a class="css3animate menu-hide btn btn-outline fnt-small rounded-0 px-4 mt-4" href="<?php echo e(url('/post').'/'.$post->slug); ?>">
                                <?php echo e(Str::upper(__('content.load_more'))); ?>

                            </a>
                            <?php endif; ?>

                        <?php if($loop->first): ?>
                            </a>
                        <?php else: ?> 
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        
        </div>
    </section>
</div>
<?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/fronted/sections/blog.blade.php ENDPATH**/ ?>