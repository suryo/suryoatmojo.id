<?php $__env->startSection('title', trans('installer_messages.final.title')); ?>
<?php $__env->startSection('container'); ?>
    <div class="alert alert-success text-center my-3" role="alert">
        <p class="m-0"><?php echo e(session('message')['message']); ?></p>
    </div>
    <div class="modal-footer d-flex justify-content-center border-0">
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary"><?php echo e(trans('installer_messages.final.exit')); ?></a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/vendor/installer/finished.blade.php ENDPATH**/ ?>