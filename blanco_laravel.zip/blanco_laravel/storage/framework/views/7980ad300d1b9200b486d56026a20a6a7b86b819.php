<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.footer')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.footer')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/').'/admin/footer'); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">                           
                                <div class="col-md-6 mb-2">
                                    <div class="form-group">
                                        <label for="top_button" class="form-label"><?php echo e(__('content.top_button')); ?></label>
                                        <div class="form-switch mb-3">
                                            <input class="form-check-input" type="checkbox" name="top_button" <?php echo e(($footer->top_button == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="cv_enable"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="form-group">
                                        <label for="copyright" class="form-label"><?php echo e(__('content.copyright')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="copyright" value="<?php echo e($footer->copyright); ?>" />
                                        <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="form-group">
                                        <label for="columns" class="form-label"><?php echo e(__('content.columns')); ?></label>
                                        <select class="form-select select-footer-columns <?php $__errorArgs = ['columns'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="columns">
                                            <option value="0" <?php echo ($footer->columns == 0) ? 'selected' : ''; ?>>0</option>
                                            <option value="2" <?php echo ($footer->columns == 2) ? 'selected' : ''; ?>>2</option>
                                            <option value="3" <?php echo ($footer->columns == 3) ? 'selected' : ''; ?>>3</option>
                                            <option value="4" <?php echo ($footer->columns == 4) ? 'selected' : ''; ?>>4</option>
                                        </select>
                                    </div>
                                </div>
                                
                                
                                <div class="col-12 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.column')); ?> 1</h4>
                                </div>
                                <div class="col-md-6 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_1_subtitle" class="form-label"><?php echo e(__('content.column')); ?> 1 -> <?php echo e(__('content.subtitle')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_1_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_1_subtitle" value="<?php echo e($footer->column_1_subtitle); ?>" />
                                        <?php $__errorArgs = ['column_1_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_1_title" class="form-label"><?php echo e(__('content.column')); ?> 1 -> <?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_1_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_1_title" value="<?php echo e($footer->column_1_title); ?>" />
                                        <?php $__errorArgs = ['column_1_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_1_social" class="form-label"><?php echo e(__('content.social_links')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="column_1_social" <?php echo e(($footer->column_1_social == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="column_1_social"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_1_content" class="form-label"><?php echo e(__('content.column')); ?> 1 -> <?php echo e(__('content.content')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['column_1_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="column_1_content" rows="5"><?php echo e($footer->column_1_content); ?></textarea>
                                        <?php $__errorArgs = ['column_1_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="col-12 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.column')); ?> 2</h4>
                                </div>
                                <div class="col-md-6 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_2_subtitle" class="form-label"><?php echo e(__('content.column')); ?> 2 -> <?php echo e(__('content.subtitle')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_2_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_2_subtitle" value="<?php echo e($footer->column_2_subtitle); ?>" />
                                        <?php $__errorArgs = ['column_2_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_2_title" class="form-label"><?php echo e(__('content.column')); ?> 2 -> <?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_2_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_2_title" value="<?php echo e($footer->column_2_title); ?>" />
                                        <?php $__errorArgs = ['column_2_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_2_social" class="form-label"><?php echo e(__('content.social_links')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="column_2_social" <?php echo e(($footer->column_2_social == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="column_2_social"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2 column_1_2 <?php echo ($footer->columns == 0) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_2_content" class="form-label"><?php echo e(__('content.column')); ?> 2 -> <?php echo e(__('content.content')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['column_2_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="column_2_content" rows="5"><?php echo e($footer->column_2_content); ?></textarea>
                                        <?php $__errorArgs = ['column_2_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="col-12 mb-2 column_3 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) ) ? 'd-none' : '' ?>">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.column')); ?> 3</h4>
                                </div>
                                <div class="col-md-6 mb-2 column_3 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) ) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_3_subtitle" class="form-label"><?php echo e(__('content.column')); ?> 3 -> <?php echo e(__('content.subtitle')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_3_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_3_subtitle" value="<?php echo e($footer->column_3_subtitle); ?>" />
                                        <?php $__errorArgs = ['column_3_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_3_title" class="form-label"><?php echo e(__('content.column')); ?> 3 -> <?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_3_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_3_title" value="<?php echo e($footer->column_3_title); ?>" />
                                        <?php $__errorArgs = ['column_3_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_3_social" class="form-label"><?php echo e(__('content.social_links')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="column_3_social" <?php echo e(($footer->column_3_social == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="column_3_social"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2 column_3 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) ) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_3_content" class="form-label"><?php echo e(__('content.column')); ?> 3 -> <?php echo e(__('content.content')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['column_3_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="column_3_content" rows="5"><?php echo e($footer->column_3_content); ?></textarea>
                                        <?php $__errorArgs = ['column_3_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="col-12 mb-2 column_4 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) || ($footer->columns == 3)) ? 'd-none' : '' ?>">
                                    <hr class="mt-4 mb-5 border-0">
                                    <h4 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.column')); ?> 4</h4>
                                </div>
                                <div class="col-md-6 mb-2 column_4 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) || ($footer->columns == 3)) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_4_subtitle" class="form-label"><?php echo e(__('content.column')); ?> 4 -> <?php echo e(__('content.subtitle')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_4_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_4_subtitle" value="<?php echo e($footer->column_4_subtitle); ?>" />
                                        <?php $__errorArgs = ['column_4_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_4_title" class="form-label"><?php echo e(__('content.column')); ?> 4 -> <?php echo e(__('content.title')); ?></label>
                                        <input class="form-control <?php $__errorArgs = ['column_4_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="column_4_title" value="<?php echo e($footer->column_4_title); ?>" />
                                        <?php $__errorArgs = ['column_4_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 55.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="column_4_social" class="form-label"><?php echo e(__('content.social_links')); ?></label>
                                        <div class="form-switch mb-2">
                                            <input class="form-check-input" type="checkbox" name="column_4_social" <?php echo e(($footer->column_4_social == 1) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="column_4_social"><?php echo e(__('content.enable')); ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2 column_4 <?php echo ( ($footer->columns == 0) || ($footer->columns == 2) || ($footer->columns == 3)) ? 'd-none' : '' ?>">
                                    <div class="form-group">
                                        <label for="column_4_content" class="form-label"><?php echo e(__('content.column')); ?> 4 -> <?php echo e(__('content.content')); ?></label>
                                        <textarea class="form-control <?php $__errorArgs = ['column_4_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="column_4_content" rows="5"><?php echo e($footer->column_4_content); ?></textarea>
                                        <?php $__errorArgs = ['column_4_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e(__('content.text_not_valid')); ?> <?php echo e(__('content.max_characters')); ?>: 255.
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/footer.blade.php ENDPATH**/ ?>