<section class="testimonials back-image pt-8 pb-9 py-5 <?php echo e($section->testimonial_scheme_color); ?>" 
    data-image="<?php echo e(!empty($section->testimonial_background) ? $section->testimonial_background : 'null'); ?>">
    <div class="container">
        <div class="row">
            <?php if(count($testimonials)>0): ?>
            <div class="testimonials-messages py-3 py-md-0 px-4 px-md-0" data-interval="<?php echo e($section->testimonial_interval); ?>" data-autoplay="<?php echo e($section->testimonial_autoplay); ?>">
                
                <div class="row d-flex align-items-stretch">
                    <div class="col-6 col-md-4 offset-md-1 py-5 testimonial-images d-none d-md-block">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="testimonial-image back-image <?php echo e(($section->testimonial_scheme_color == 'light-scheme') ? 'dark-scheme' : 'light-scheme'); ?>" data-image="<?php echo e($testimonial->image); ?>">
                            <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'quotes']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'testimonial-images-quotes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                    <div class="col-12 col-md-6">
                        <div class="testimonial-content <?php echo e(($section->testimonial_scheme_color == 'light-scheme') ? 'dark-scheme' : 'light-scheme'); ?>">
                            <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'quotes']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'comment-quotes mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'waves']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'waves']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                            <div class="testimonial-texts">
                                <?php $i = 0; ?>
                                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <p class="comment mb-4 header-font"><?php echo e($testimonial->text); ?></p>
                                    <p class="comment-name text-uppercase pt-2 m-0 fnt-bold"><?php echo e($testimonial->name); ?> | <?php echo e($testimonial->company); ?></p>
                                    <?php if($section->testimonial_autoplay == 0): ?>
                                    <div class="comments-arrows mt-4 mt-md-5">
                                        <button class="border-0 bg-transparent left-arrow me-3" data-index="<?php echo e($i-1); ?>">
                                            <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'arrow-left']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'css3animate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                                        </button>
                                        <button class="border-0 bg-transparent right-arrow" data-index="<?php echo e($i+1); ?>">
                                            <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'arrow-right']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'css3animate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php $i++; ?>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>  
                </div>  

            </div>  
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/sections/subsections/testimonials.blade.php ENDPATH**/ ?>