<div class="pt-page aboutme <?php echo e($section->about_scheme_color); ?>" data-colorScheme="<?php echo e($section->about_scheme_color); ?>" data-overflow="1">
    <section class="aboutme-title">
        <div class="container-fluid">
            <div class="row">
                <?php if($personal->image != null): ?>
                    <div class="col-12 col-md-6 aboutme-image back-image pt-12 pb-9 background-secondary" data-image="<?php echo e($personal->image); ?>"></div>
                <?php endif; ?>
                <div class="<?php echo e($personal->image != null ? 'col-12 col-md-6 pt-12 pb-9 aboutme-texts py-5' : 'col-12 col-md-6 offset-md-3 pt-12 pb-9 text-center py-5b'); ?>">
                    <?php if($personal->title != ''): ?>
                        <?php
                        $title = str_replace("/*", "<span class='underlined'>", $personal->title);
                        $title = str_replace("*/", "</span>", $title);
                        ?>
                        <h1 class="mb-4 mb-md-5"><?php echo $title; ?></h1>
                    <?php endif; ?>
                    <?php if($personal->description != ''): ?>
                        <h4 class="fw-normal mb-4 mb-md-5"><?php echo $personal->description; ?></h4>
                    <?php endif; ?>
                    <?php if($personal->cv_enable == 1 && $personal->cv_text != '' && $personal->cv_file != null): ?>
                        <a class="btn <?php echo e(($section->about_scheme_color = "dark-scheme") ? 'btn-outline' : ''); ?> py-3 px-5 text-uppercase fw-bold" href="<?php echo e($personal->cv_file); ?>" title="<?php echo e($personal->cv_text); ?>" target="_blank"><?php echo e($personal->cv_text); ?></a>    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <?php if(!empty($personal->info) && ($personal->info != '[]')): ?>
    <section class="py-4b aboutme-info border-top border-bottom">
        <div class="container">
            <div class="row">
                <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'waves']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'waves waves-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'waves']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'waves waves-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                <?php
                $personal_info = json_decode($personal->info);
                $class_column = (count($personal_info) > 4) ? 'col-md-3' : 'col-md-'.(12/count($personal_info));
                foreach($personal_info as $info){
                    echo '
                    <div class="col-6 '.$class_column.' aboutme-info-content text-center">
                        <h2 class="mb-2">'.$info->text.'</span></h2>
                        <p class="text-uppercase">'.$info->title.'</p>
                    </div>';
                }
                ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($section->skills_enable == true): ?>
        <?php echo $__env->make('fronted.sections.subsections.skills', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->testimonial_enable == true): ?>
        <?php echo $__env->make('fronted.sections.subsections.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php if($section->services_enable == true): ?>
        <?php echo $__env->make('fronted.sections.subsections.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/fronted/sections/about.blade.php ENDPATH**/ ?>