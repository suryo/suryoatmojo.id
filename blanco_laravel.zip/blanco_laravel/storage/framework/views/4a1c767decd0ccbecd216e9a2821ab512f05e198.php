<section class="services back-image pt-8 pb-9 py-5 <?php echo e($section->services_scheme_color); ?>" 
    data-image="<?php echo e(!empty($section->services_background) ? $section->services_background : 'null'); ?>">
    <div class="container">
            
        <div class="row">
            <div class="col-12 col-md-6">
            <?php if(!empty($section->services_subtitle)): ?>
                <p class="mb-2 accent-color fnt-bold"><?php echo e($section->services_subtitle); ?></p>
            <?php endif; ?>
            <?php if(!empty($section->services_title)): ?>
                <h2 class="m-0 mt-3 mt-sm-0"><?php echo e($section->services_title); ?></h2>
            <?php endif; ?>
            </div>
            <?php if(count($services)>0): ?>
            <div class="col-12 col-md-6 carousel-nav d-flex justify-content-start justify-content-md-end align-items-end mt-4 mt-md-0">
                <button class="rounded-circle me-3 css3animate left-nav">
                    <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'arrow-left']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'css3animate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                </button>
                <button class="rounded-circle css3animate right-nav">
                    <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'arrow-right']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'css3animate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?>
                </button>
            </div>
            <?php endif; ?>
        </div>
            
        <?php if(count($services)>0): ?>
        <div class="row services-content mt-4 mt-sm-5" data-columns="<?php echo e($section->services_columns); ?>">
        
            <div class="owl-carousel owl-theme services-carousel mt-4">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item p-4 p-md-5 css3animate">
                    <i class="<?php echo e($service->icon); ?> css3animate mb-4"></i>
                    <h3 class="mb-4 css3animate"><?php echo e($service->title); ?></h3>
                    <p class="service-desc css3animate"><?php echo e($service->description); ?></p>
                    <?php
                    $service_info_array = json_decode($service->info);
                    if (!is_null($service_info_array)){
                        echo '<ul class="service-info p-0 m-0">';
                        foreach($service_info_array as $service_info){
                            echo '
                            <li class="css3animate">+ '.$service_info->title.'</li>';
                        }
                        echo '</ul>';
                    }
                    ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
        <?php endif; ?>

    </div>
</section><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/fronted/sections/subsections/services.blade.php ENDPATH**/ ?>