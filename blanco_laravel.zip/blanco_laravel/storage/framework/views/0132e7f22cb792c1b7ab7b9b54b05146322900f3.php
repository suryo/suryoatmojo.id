<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.skills')); ?></h1>
        <button type="button" class="btn btn-primary btn-round d-inline" data-bs-toggle="modal" data-bs-target="#skillNewModal">
            <i class="fas fa-plus small"></i>
            <?php echo e(__('content.add_skill')); ?>

        </button>
    </div>

    <div class="row">
        
        
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.skills_design')); ?></h6>
                </div>
                <div class="card-body">
                    <?php if(count($design_skills) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.title')); ?></th>
                                        <th><?php echo e(__('content.percentage')); ?></th>
                                        <th><?php echo e(__('content.order')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $design_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design_skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td class="text-capitalize"><?php echo e($design_skill->title); ?></td>
                                            <td><?php echo e($design_skill->percentage); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if($i < count($design_skills)): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/skills/order-down/<?php echo e($design_skill->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-down"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($i != 1): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/skills/order-up/<?php echo e($design_skill->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-up"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/skills/<?php echo e($design_skill->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/skills')); ?>/<?php echo e($design_skill->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteSkill<?php echo e($design_skill->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deleteSkill<?php echo e($design_skill->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_skills_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.skills_development')); ?></h6>
                </div>
                <div class="card-body">
                    <?php if(count($dev_skills) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="custom-width" scope="col">#</th>
                                        <th><?php echo e(__('content.title')); ?></th>
                                        <th><?php echo e(__('content.percentage')); ?></th>
                                        <th><?php echo e(__('content.order')); ?></th>
                                        <th class="custom-width-action"><?php echo e(__('content.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $j = 1; ?>
                                    <?php $__currentLoopData = $dev_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev_skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($j); ?></td>
                                            <td><?php echo e($dev_skill->title); ?></td>
                                            <td><?php echo e($dev_skill->percentage); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <?php if($j < count($dev_skills)): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/skills/order-down/<?php echo e($dev_skill->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-down"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($j != 1): ?>
                                                        <a href="<?php echo e(url('/')); ?>/admin/skills/order-up/<?php echo e($dev_skill->id); ?>" class="btn btn-warning btn-sm mr-1">
                                                            <i class="fas fa-arrow-up"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(url('/')); ?>/admin/skills/<?php echo e($dev_skill->id); ?>" class="btn btn-primary btn-sm mr-1">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                    <form class="d-inline-block" action="<?php echo e(url('/admin/skills')); ?>/<?php echo e($dev_skill->id); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteSkill<?php echo e($dev_skill->id); ?>">
                                                            <i class="far fa-trash-alt"></i>
                                                        </button>
                                                        <div class="modal fade" id="deleteSkill<?php echo e($dev_skill->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('Delete')); ?></h5>
                                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="<?php echo e(__('content.close')); ?>">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php echo e(__('content.sure_delete')); ?>

                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-success"><?php echo e(__('content.yes_delete')); ?></button>
                                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo e(__('content.cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $j++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <?php echo e(__('content.no_skills_created_yet')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>


<!-- MODAL TO CREATE A NEW SKILL -->
<div class="modal fade" id="skillNewModal" tabindex="-1" role="dialog" aria-labelledby="skillNewModalModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('content.new_skill')); ?></h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('/').'/admin/skills'); ?>" method="POST" class="user">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" name="order_design" value="<?php echo (count($design_skills) > 0) ? $i : 1; ?>" />
                        <input type="hidden" name="order_dev" value="<?php echo (count($dev_skills) > 0) ? $j : 1; ?>" />
                        <div class="col-md-12 mb-3">
                            <label for="type" class="form-label"><?php echo e(__('content.type')); ?></label>
                            <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type">
                                <option value="design"><?php echo e(__('content.design')); ?></option>
                                <option value="development"><?php echo e(__('content.development')); ?></option>
                            </select>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="title" class="form-label"><?php echo e(__('content.title')); ?></label>
                            <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" required value="<?php echo e(old('title')); ?>"/>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.text_not_valid')); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="col-md-12">
                            <label for="percentage" class="form-label"><?php echo e(__('content.percentage')); ?></label>
                            <input class="form-control <?php $__errorArgs = ['percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" min="0" max="100" name="percentage" required value="<?php echo e(old('percentage')); ?>"/>
                            <?php $__errorArgs = ['percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e(__('content.number_not_valid')); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('content.add')); ?>

                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('content.close')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if(Session::has('error-modal')): ?>
    <input class="openModal" data-id="skillNewModal" type="hidden" val="1" />
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blanco_laravel\resources\views/admin/pages/skills/skills.blade.php ENDPATH**/ ?>