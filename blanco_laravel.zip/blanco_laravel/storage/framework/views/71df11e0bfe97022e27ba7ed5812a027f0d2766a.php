<?php $__env->startSection('content'); ?>

<?php if($section->slider_enable == 1): ?>
    <div id="pattern"></div>
<?php endif; ?>

<div class="pt-wrapper">

    
    <?php if($general->loader == true): ?>
        <?php echo $__env->make('fronted.sections.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php
        
    ?>

    <div class="pt-page blog-post pb-5 <?php echo e($section->blog_scheme_color); ?>" data-overflow="1">
        <section class="container-fluid <?php if($post->type == 'standard'): ?>back-image post-image <?php endif; ?>"
            <?php if($post->type == 'standard'): ?>data-image="<?php echo e(url('/')); ?>/<?php echo e($post->image); ?>" <?php endif; ?>>
            <div class="row post-title-container pt-5 pt-8 d-flex flex-column">
                <div class="col-12 col-md-8 offset-md-2 col-lg-6 offset-lg-3 text-center">
                    <a href="<?php echo e(url('/')); ?>?blog_active=1" class="project-title css3animate post-hide menu-show py-1 px-3" data-style="<?php echo e($section->blog_scheme_color); ?>">
                        <?php if (isset($component)) { $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57 = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Icon::class, ['name' => 'arrow-left']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'css3animate me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57)): ?>
<?php $component = $__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57; ?>
<?php unset($__componentOriginal779f02523774900e08811a4bd172ab9aa81abe57); ?>
<?php endif; ?> <?php echo e((__('content.blog'))); ?>

                    </a>
                    <h2 class="post-title my-3 my-lg-4"><?php echo e($post->title); ?></h2>
                    <p class="post-info m-0">
                        <?php echo e($post->date_formated); ?> <span class="mx-2">|</span> <?php echo e($post->category_name); ?>

                    </p>
                </div>
            </div>
        </section>
        <section class="container container-media py-5">
            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2 post-media">
                    <?php switch($post->type):
                        case ('gallery'): ?>
                            <div class="post-gallery mb-4 mb-lg-5">
                                <div id="gallery-post-<?php echo e($post->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                    <ol class="carousel-indicators">
                                    <?php for($i = 0; $i < $post->gallery_image_number; $i++): ?>
                                        <li data-bs-target="#gallery-post-<?php echo e($post->id); ?>" data-bs-slide-to="<?php echo e($i); ?>" <?php if($i == 0): ?> class="active" <?php endif; ?>></li>
                                    <?php endfor; ?>
                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <?php for($i = 0; $i < $post->gallery_image_number; $i++): ?>
                                            <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
                                                <img src="<?php echo e(url('/')); ?>/<?php echo e($post->gallery_images[$i + 1]); ?>" class="d-block w-100" alt="<?php echo e($post->title); ?>" />
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                        <?php break; ?>
                        <?php case ('video'): ?>
                            <div class="post-video mb-4 mb-lg-5">
                                <?php echo $post->video; ?>

                            </div>
                        <?php break; ?>
                        <?php case ('quote'): ?>
                            <div class="post-quote p-4 p-md-5 mb-4 mb-lg-5">
                                <h3 class="mb-3"><?php echo e($post->quote_text); ?></h3>
                                <p class="m-0">- <?php echo e($post->quote_author); ?></p>
                            </div>  
                        <?php break; ?>
                    <?php endswitch; ?>
                </div>
                <div class="col-12 col-lg-8 offset-lg-2 post-content content-text"><?php echo $post->text; ?></div>
            </div>
        </section>
    </div>

    
    <?php if($general->cookies_enable == 1): ?>
        <?php echo $__env->make('fronted.sections.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>
<!-- END PT-WRAPPER  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fronted.post_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/fronted/post.blade.php ENDPATH**/ ?>