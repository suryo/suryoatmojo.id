<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <?php echo $__env->make('admin.modules.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('content.styles')); ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- DataTales -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="font-weight-bold text-primary m-0"><?php echo e(__('content.styles')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/').'/admin/styles'); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="font_head" class="form-label"><?php echo e(__('content.font_head')); ?></label>
                                        <select class="form-select" name="font_head" required>
                                            <?php $__currentLoopData = $fonts_heading; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo ($style->font_head == $key) ? 'selected' : ''; ?>><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="font_main" class="form-label"><?php echo e(__('content.font_main')); ?></label>
                                        <select class="form-select" name="font_main" required>
                                            <?php $__currentLoopData = $fonts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo ($style->font_main == $key) ? 'selected' : ''; ?>><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <hr class="mt-3 mb-4 border-0">
                                    <h5 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.light_scheme')); ?></h5>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_head_color" class="form-label"><?php echo e(__('content.heading')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_head_color" value="<?php echo e($style->light_head_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_main_color" class="form-label"><?php echo e(__('content.text')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_main_color" value="<?php echo e($style->light_main_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_back_main_color" class="form-label"><?php echo e(__('content.back_main')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_back_main_color" value="<?php echo e($style->light_back_main_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_accent_color" class="form-label"><?php echo e(__('content.accent')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_accent_color" value="<?php echo e($style->light_accent_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_accent_hover_color" class="form-label"><?php echo e(__('content.accent_hover')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_accent_hover_color" value="<?php echo e($style->light_accent_hover_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="light_back_secondary_color" class="form-label"><?php echo e(__('content.back_sec')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="light_back_secondary_color" value="<?php echo e($style->light_back_secondary_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>

                                <div class="col-12 mb-3">
                                    <hr class="mt-3 mb-4 border-0">
                                    <h5 class="mt-3 mb-2 text-gray-800 fw-bold"><?php echo e(__('content.dark_scheme')); ?></h5>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_head_color" class="form-label"><?php echo e(__('content.heading')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_head_color" value="<?php echo e($style->dark_head_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_main_color" class="form-label"><?php echo e(__('content.text')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_main_color" value="<?php echo e($style->dark_main_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_back_main_color" class="form-label"><?php echo e(__('content.back_main')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_back_main_color" value="<?php echo e($style->dark_back_main_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_accent_color" class="form-label"><?php echo e(__('content.accent')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_accent_color" value="<?php echo e($style->dark_accent_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_accent_hover_color" class="form-label"><?php echo e(__('content.accent_hover')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_accent_hover_color" value="<?php echo e($style->dark_accent_hover_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="dark_back_secondary_color" class="form-label"><?php echo e(__('content.back_sec')); ?></label>
                                        <input type="color" class="form-control form-control-color" name="dark_back_secondary_color" value="<?php echo e($style->dark_back_secondary_color); ?>" title="Choose your color" required />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('content.update')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blanco_laravel/resources/views/admin/pages/style.blade.php ENDPATH**/ ?>